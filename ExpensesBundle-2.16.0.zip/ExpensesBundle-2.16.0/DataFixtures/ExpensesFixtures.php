<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\DataFixtures;

use App\DataFixtures\CustomerFixtures;
use App\DataFixtures\UserFixtures;
use App\Entity\Activity;
use App\Entity\Project;
use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Bundle\FixturesBundle\FixtureGroupInterface;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;

/**
 * Defines the sample data to load in the database when running the unit and
 * functional tests or while development.
 *
 * Execute this command to load the data:
 * bin/console doctrine:fixtures:load --append --group=expense
 *
 * @codeCoverageIgnore
 */
class ExpensesFixtures extends Fixture implements DependentFixtureInterface, FixtureGroupInterface
{
    public const MIN_EXPENSES_PER_USER = 10;
    public const MAX_EXPENSES_PER_USER = 100;
    public const MAX_EXPENSES_TOTAL = 5000;
    public const TIMERANGE_DAYS = 1095; // 3 years
    public const MAX_DESCRIPTION_LENGTH = 50;

    public const BATCH_SIZE = 100;

    public static function getGroups(): array
    {
        return ['expense'];
    }

    /**
     * @return array<class-string<FixtureInterface>>
     */
    public function getDependencies(): array
    {
        return [
            UserFixtures::class,
            CustomerFixtures::class,
        ];
    }

    public function load(ObjectManager $manager): void
    {
        $faker = Factory::create();

        $categoriesOld = $this->getAllCategories($manager);

        $categories = [
            'Travel' => 0.3,
            'Catering' => 1,
            'Parking' => 1,
            'Rent' => 1,
            'Insurance' => 0.5,
            'Clothing' => null,
            'Communication' => 1,
            'Business lunch' => 1,
            'Miscellaneous' => 1,
            'Internal' => 0,
        ];

        foreach ($categories as $name => $cost) {
            foreach ($categoriesOld as $cat) {
                if ($cat->getName() === $name) {
                    continue 2;
                }
            }
            $category = new ExpenseCategory($name);
            $category->setCost($cost);

            if (null === $cost) {
                $category->setVisible(false);
            }

            $manager->persist($category);
        }

        $manager->flush();

        $allUser = $this->getAllUsers($manager);
        $activities = $this->getAllActivities($manager);
        $projects = $this->getAllProjects($manager);
        $categories = $this->getAllCategories($manager);
        $all = 0;

        foreach ($allUser as $user) {
            $expensesForUser = mt_rand(self::MIN_EXPENSES_PER_USER, self::MAX_EXPENSES_PER_USER);
            for ($i = 1; $i <= $expensesForUser; $i++) {
                if ($all > self::MAX_EXPENSES_TOTAL) {
                    break;
                }

                $description = null;
                if ($i % 3 === 0) {
                    $description = $faker->realText($faker->numberBetween(10, self::MAX_DESCRIPTION_LENGTH));
                } elseif ($i % 5 === 0) {
                    $description = substr($faker->catchPhrase(), 0, self::MAX_DESCRIPTION_LENGTH);
                }

                $entry = $this->createExpense(
                    $user,
                    $activities[array_rand($activities)],
                    $projects[array_rand($projects)],
                    $categories[array_rand($categories)],
                    $description
                );

                $all++;

                $manager->persist($entry);

                if ($i % self::BATCH_SIZE == 0) {
                    $manager->flush();
                }
            }

            $manager->flush();
        }

        $manager->flush();
    }

    /**
     * @return ExpenseCategory[]
     */
    protected function getAllCategories(ObjectManager $manager): array
    {
        $all = [];
        /* @var ExpenseCategory[] $entries */
        $entries = $manager->getRepository(ExpenseCategory::class)->findAll();
        foreach ($entries as $temp) {
            $all[$temp->getId()] = $temp;
        }

        return $all;
    }

    /**
     * @return User[]
     */
    protected function getAllUsers(ObjectManager $manager): array
    {
        $all = [];
        /* @var User[] $entries */
        $entries = $manager->getRepository(User::class)->findAll();
        foreach ($entries as $temp) {
            $all[$temp->getId()] = $temp;
        }

        return $all;
    }

    /**
     * @return Project[]
     */
    protected function getAllProjects(ObjectManager $manager): array
    {
        $all = [];
        /* @var Project[] $entries */
        $entries = $manager->getRepository(Project::class)->findAll();
        foreach ($entries as $temp) {
            $all[$temp->getId()] = $temp;
        }

        return $all;
    }

    /**
     * @return Activity[]
     */
    protected function getAllActivities(ObjectManager $manager): array
    {
        $all = [];
        /* @var Activity[] $entries */
        $entries = $manager->getRepository(Activity::class)->findAll();
        foreach ($entries as $temp) {
            $all[$temp->getId()] = $temp;
        }

        return $all;
    }

    private function createExpense(User $user, Activity $activity, Project $project, ExpenseCategory $category, ?string $description = null): Expense
    {
        $start = new \DateTimeImmutable();
        $start = $start->modify('- ' . (mt_rand(1, self::TIMERANGE_DAYS)) . ' days');
        $start = $start->modify('- ' . (mt_rand(1, 86400)) . ' seconds');
        $start = $start->setTimezone(new \DateTimeZone($user->getTimezone()));

        $cost = 0.00;
        if ($category->getCost() !== null) {
            $cost = $category->getCost();
        }

        $entry = new Expense();
        $entry->setActivity($activity);
        $entry->setProject($activity->getProject() ?? $project);
        $entry->setDescription($description);
        $entry->setUser($user);
        $entry->setExpenseCategory($category);
        $entry->setBegin($start);
        $entry->setRefundable(mt_rand(1, 86400) % 4 !== 0);
        $entry->setMultiplier((float) mt_rand(1, 9999));
        $entry->setCost($cost);

        return $entry;
    }
}
