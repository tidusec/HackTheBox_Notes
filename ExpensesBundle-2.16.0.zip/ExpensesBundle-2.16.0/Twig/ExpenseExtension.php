<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Twig;

use KimaiPlugin\ExpensesBundle\Export\ExpenseExportService;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class ExpenseExtension extends AbstractExtension
{
    public function __construct(private readonly ExpenseExportService $expenseExportService)
    {
    }

    public function getFunctions(): array
    {
        return [
            new TwigFunction('expense_exporter', $this->getExporter(...), []),
        ];
    }

    /**
     * @return array<string>
     */
    public function getExporter(): array
    {
        $ids = [];
        foreach ($this->expenseExportService->getExporter() as $exporter) {
            $ids[] = $exporter->getId();
        }

        return $ids;
    }
}
