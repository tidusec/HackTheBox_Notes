<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\API;

use App\API\BaseApiController;
use App\Repository\Query\TimesheetQuery;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\View\View;
use FOS\RestBundle\View\ViewHandlerInterface;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Event\ExpenseMetaDefinitionEvent;
use KimaiPlugin\ExpensesBundle\Form\API\ExpenseForm;
use KimaiPlugin\ExpensesBundle\Form\ExpenseToolbarForm;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesCategoryRepository;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesRepository;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;
use OpenApi\Attributes as OA;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Component\Validator\Constraints;

#[Route(path: '/expenses')]
#[OA\Tag(name: 'Expense')]
#[IsGranted('API')]
#[IsGranted('view_expense')]
class ExpenseController extends BaseApiController
{
    public const GROUPS_ENTITY = ['Default', 'Entity', 'Expense', 'Expense_Entity'];
    public const GROUPS_CATEGORY = ['Default', 'Entity', 'Expense', 'Expense_Category_Entity'];
    public const GROUPS_FORM = ['Default', 'Entity', 'Expense'];
    public const GROUPS_COLLECTION = ['Default', 'Collection', 'Expense'];

    public function __construct(
        private readonly ViewHandlerInterface $viewHandler,
        private readonly ExpensesRepository $repository,
        private readonly EventDispatcherInterface $dispatcher
    )
    {
    }

    /**
     * Returns a collection of expenses
     *
     * The result is paginated, by default limited to 50 entries.
     */
    #[OA\Response(response: 200, description: 'Returns a collection of expense entities', content: new OA\JsonContent(type: 'array', items: new OA\Items(ref: '#/components/schemas/ExpenseEntity')))]
    #[Rest\QueryParam(name: 'users[]', requirements: '[\d|,]+', strict: true, nullable: true, description: 'User IDs')]
    #[Rest\QueryParam(name: 'customers[]', requirements: '[\d|,]+', strict: true, nullable: true, description: 'Customer IDs')]
    #[Rest\QueryParam(name: 'projects[]', requirements: '[\d|,]+', strict: true, nullable: true, description: 'Project IDs')]
    #[Rest\QueryParam(name: 'activities[]', requirements: '[\d|,]+', strict: true, nullable: true, description: 'Activity IDs')]
    #[Rest\QueryParam(name: 'begin', requirements: new Constraints\DateTime(format: 'Y-m-d\TH:i:s'), strict: true, nullable: true, description: 'Only records after this date will be included (format: HTML5)')]
    #[Rest\QueryParam(name: 'end', requirements: new Constraints\DateTime(format: 'Y-m-d\TH:i:s'), strict: true, nullable: true, description: 'Only records before this date will be included (format: HTML5)')]
    #[Rest\QueryParam(name: 'refundable', requirements: '0|1', strict: true, nullable: true, description: 'Use this flag if you want to filter for refundable expenses. Allowed values: 0=not refundable, 1=refundable (default: all)')]
    #[Rest\QueryParam(name: 'exported', requirements: '0|1', strict: true, nullable: true, description: 'Use this flag if you want to filter for export state. Allowed values: 0=not exported, 1=exported (default: all)')]
    #[Rest\QueryParam(name: 'term', nullable: true, requirements: '[a-zA-Z0-9 \-,:]+', strict: true, description: 'Free search term')]
    #[Rest\QueryParam(name: 'orderBy', requirements: 'begin|duration|multiplier|cost|total|category|user|customer|project|activity|description|exported|refundable', strict: true, nullable: true, description: 'The field by which results will be ordered. Allowed values: begin, end, duration, total, category, cost, user, customer, project, activity, description, exported, refundable, multiplier (default: begin)')]
    #[Rest\QueryParam(name: 'order', requirements: 'ASC|DESC', strict: true, nullable: true, description: 'The result order. Allowed values: ASC, DESC (default: DESC)')]
    #[Rest\QueryParam(name: 'page', requirements: '\d+', strict: true, nullable: true, description: 'The page to display, renders a 404 if not found (default: 1)')]
    #[Rest\QueryParam(name: 'size', requirements: '\d+', strict: true, nullable: true, description: 'The amount of entries for each page (default: 50)')]
    #[Route(methods: ['GET'], path: '', name: 'get_expenses')]
    public function cgetAction(Request $request, ParamFetcherInterface $paramFetcher): Response
    {
        $viewOthers = $this->isGranted('view_other_timesheet');

        $query = new ExpenseQuery();
        if (!$viewOthers) {
            $query->setUser($this->getUser());
        }

        if (null !== ($page = $paramFetcher->get('page'))) {
            $query->setPage($page);
        }

        if (null !== ($size = $paramFetcher->get('size'))) {
            $query->setPageSize((int) $size);
            $request->query->remove('size');
        }

        if (null !== ($begin = $paramFetcher->get('begin'))) {
            $query->setBegin($this->getDateTimeFactory()->createDateTime($begin));
            $request->query->remove('begin');
        }

        if (null !== ($end = $paramFetcher->get('end'))) {
            $query->setEnd($this->getDateTimeFactory()->createDateTime($end));
            $request->query->remove('end');
        }

        if (null !== ($exported = $paramFetcher->get('exported'))) {
            $exported = (int) $exported;
            if ($exported === 1) {
                $query->setExported(TimesheetQuery::STATE_EXPORTED);
            } elseif ($exported === 0) {
                $query->setExported(TimesheetQuery::STATE_NOT_EXPORTED);
            }
            $request->query->remove('exported');
        }

        if (null !== ($refundable = $paramFetcher->get('refundable'))) {
            $refundable = (int) $refundable;
            if ($refundable === 1) {
                $query->setBillable(true);
            } elseif ($refundable === 0) {
                $query->setBillable(false);
            }
            $request->query->remove('refundable');
        }

        $form = $this->createSearchForm(ExpenseToolbarForm::class, $query, [
            'include_user' => $viewOthers,
        ]);

        $submitData = $request->query->all();

        $form->submit($submitData, false);

        if (!$form->isValid()) {
            return $this->viewHandler->handle(new View($form));
        }

        $query->setIsApiCall(true);
        $data = $this->repository->getPagerfantaForQuery($query);
        $data = (array) $data->getCurrentPageResults();

        $view = new View($data, 200);
        $view->getContext()->setGroups(self::GROUPS_COLLECTION);

        return $this->viewHandler->handle($view);
    }

    /**
     * Returns one expense
     */
    #[OA\Response(response: 200, description: 'Returns one expense entity', content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEntity'))]
    #[OA\Parameter(name: 'id', in: 'path', description: 'Expense ID to fetch', required: true)]
    #[Route(methods: ['GET'], path: '/{id}', name: 'get_expense', requirements: ['id' => '\d+'])]
    #[IsGranted('view_expense', 'expense')]
    public function getAction(Expense $expense): Response
    {
        $view = new View($expense, 200);
        $view->getContext()->setGroups(self::GROUPS_ENTITY);

        return $this->viewHandler->handle($view);
    }

    /**
     * Creates a new expense
     */
    #[OA\Post(description: 'Creates a new expense and returns it afterwards', responses: [new OA\Response(response: 200, description: 'Returns the new created expense', content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEntity'))])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEditForm'))]
    #[Route(methods: ['POST'], path: '', name: 'post_expense')]
    #[IsGranted('create_expense')]
    public function postAction(Request $request): Response
    {
        $expense = new Expense();
        $expense->setUser($this->getUser());

        $event = new ExpenseMetaDefinitionEvent($expense);
        $this->dispatcher->dispatch($event);

        $form = $this->createForm(ExpenseForm::class, $expense, [
            'include_exported' => $this->isGranted('edit_exported_expense'),
            'include_cost' => $this->isGranted('edit_expense_cost'),
            'include_user' => $this->isGranted('view_other_timesheet'),
            'timezone' => $this->getDateTimeFactory()->getTimezone()->getName(),
        ]);

        $form->submit($request->request->all());

        if ($form->isValid()) {
            $this->repository->saveExpense($expense);

            $view = new View($expense, 200);
            $view->getContext()->setGroups(self::GROUPS_ENTITY);

            return $this->viewHandler->handle($view);
        }

        $view = new View($form);
        $view->getContext()->setGroups(self::GROUPS_FORM);

        return $this->viewHandler->handle($view);
    }

    /**
     * Update an existing expense
     */
    #[OA\Patch(description: 'Update an existing expense, you can pass all or just a subset of all attributes', responses: [new OA\Response(response: 200, description: 'Returns the updated expense', content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEntity'))])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEditForm'))]
    #[OA\Parameter(name: 'id', in: 'path', description: 'Expense ID to update', required: true)]
    #[Route(methods: ['PATCH'], path: '/{id}', name: 'patch_expense', requirements: ['id' => '\d+'])]
    #[IsGranted('edit_expense')]
    public function patchAction(Request $request, Expense $expense): Response
    {
        $event = new ExpenseMetaDefinitionEvent($expense);
        $this->dispatcher->dispatch($event);

        $form = $this->createForm(ExpenseForm::class, $expense, [
            'include_exported' => $this->isGranted('edit_exported_expense'),
            'include_cost' => $this->isGranted('edit_expense_cost'),
            'include_user' => $this->isGranted('view_other_timesheet'),
            'timezone' => $this->getDateTimeFactory()->getTimezone()->getName(),
        ]);

        $form->setData($expense);
        $form->submit($request->request->all(), false);

        if (false === $form->isValid()) {
            $view = new View($form, Response::HTTP_OK);
            $view->getContext()->setGroups(self::GROUPS_FORM);

            return $this->viewHandler->handle($view);
        }

        $this->repository->saveExpense($expense);

        $view = new View($expense, Response::HTTP_OK);
        $view->getContext()->setGroups(self::GROUPS_ENTITY);

        return $this->viewHandler->handle($view);
    }

    /**
     * Sets the value of a meta-field for an existing expense
     */
    #[OA\Response(response: 200, description: 'Sets the value of an existing/configured meta-field. You cannot create unknown meta-fields, if the given name is not a configured meta-field, this will return an exception.', content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEntity'))]
    #[OA\Parameter(name: 'id', in: 'path', description: 'Expense record ID to set the meta-field value for', required: true)]
    #[Rest\RequestParam(name: 'name', strict: true, nullable: false, description: 'The meta-field name')]
    #[Rest\RequestParam(name: 'value', strict: true, nullable: false, description: 'The meta-field value')]
    #[Route(methods: ['PATCH'], path: '/{id}/meta', requirements: ['id' => '\d+'])]
    #[IsGranted('edit_expense')]
    public function metaAction(Expense $expense, ParamFetcherInterface $paramFetcher): Response
    {
        $event = new ExpenseMetaDefinitionEvent($expense);
        $this->dispatcher->dispatch($event);

        $name = $paramFetcher->get('name');
        $value = $paramFetcher->get('value');

        if (null === ($meta = $expense->getMetaField($name))) {
            throw new \InvalidArgumentException('Unknown meta-field requested');
        }

        $meta->setValue($value);

        $this->repository->saveExpense($expense);

        $view = new View($expense, 200);
        $view->getContext()->setGroups(self::GROUPS_ENTITY);

        return $this->viewHandler->handle($view);
    }

    /**
     * Delete an existing expense record
     */
    #[OA\Delete(responses: [new OA\Response(response: 204, description: 'Delete one expense record')])]
    #[OA\Parameter(name: 'id', in: 'path', description: 'Expense record ID to delete', required: true)]
    #[Route(methods: ['DELETE'], path: '/{id}', name: 'delete_expense', requirements: ['id' => '\d+'])]
    #[IsGranted('delete_expense')]
    public function deleteAction(Expense $expense): Response
    {
        $this->repository->deleteExpense($expense);

        $view = new View(null, Response::HTTP_NO_CONTENT);

        return $this->viewHandler->handle($view);
    }

    /**
     * Duplicates an existing expense record
     */
    #[OA\Response(response: 200, description: 'Duplicates a expense record, resetting the export state only.', content: new OA\JsonContent(ref: '#/components/schemas/ExpenseEntity'))]
    #[OA\Parameter(name: 'id', in: 'path', description: 'Expense record ID to duplicate', required: true)]
    #[Route(methods: ['PATCH'], path: '/{id}/duplicate', name: 'duplicate_expense', requirements: ['id' => '\d+'])]
    #[IsGranted('create_expense')]
    #[IsGranted('edit_expense')]
    public function duplicateAction(Expense $expense): Response
    {
        $copyExpense = clone $expense;

        $this->repository->saveExpense($copyExpense);

        $view = new View($copyExpense, 200);
        $view->getContext()->setGroups(self::GROUPS_ENTITY);

        return $this->viewHandler->handle($view);
    }

    /**
     * Get all visible expense categories (requires "manage_expense_category" permission)
     */
    #[OA\Response(response: 200, description: 'Returns all visible expense categories', content: new OA\JsonContent(ref: '#/components/schemas/ExpenseCategory'))]
    #[Route(methods: ['GET'], path: '/categories', name: 'get_expense_categories')]
    #[IsGranted('manage_expense_category')]
    public function getCategories(ExpensesCategoryRepository $expensesCategoryRepository): Response
    {
        $categories = $expensesCategoryRepository->findBy(['visible' => true]);

        $view = new View($categories, 200);
        $view->getContext()->setGroups(self::GROUPS_CATEGORY);

        return $this->viewHandler->handle($view);
    }
}
