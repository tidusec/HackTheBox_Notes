# Expenses plugin for Kimai

A Kimai plugin to keep track of your expenses based on a customer, project and activity.

Expenses can be categorized and included in your invoices.

## Changelog

All changes and compatible versions can be found in the [CHANGELOG](CHANGELOG.md).

## Installation

The installation is explained in the store page: https://www.kimai.org/store/expenses-bundle.html

## Documentation

Available at: https://www.kimai.org/documentation/plugin-expenses.html
