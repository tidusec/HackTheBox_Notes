<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

#[\Attribute(\Attribute::TARGET_CLASS)]
class Expense extends Constraint
{
    public const MISSING_BEGIN_ERROR = 'kimai-expense-bundle-01';
    public const MISSING_PROJECT_ERROR = 'kimai-expense-bundle-05';
    public const ACTIVITY_PROJECT_MISMATCH_ERROR = 'kimai-expense-bundle-06';
    public const DISABLED_ACTIVITY_ERROR = 'kimai-expense-bundle-07';
    public const DISABLED_PROJECT_ERROR = 'kimai-expense-bundle-08';
    public const DISABLED_CUSTOMER_ERROR = 'kimai-expense-bundle-09';
    public const PROJECT_ENDED_ERROR = 'kimai-expense-bundle-10';
    public const PROJECT_NOT_STARTED_ERROR = 'kimai-expense-bundle-11';

    /**
     * @var array<string, string>
     */
    protected const ERROR_NAMES = [
        self::MISSING_BEGIN_ERROR => 'You must submit a begin date.',
        self::MISSING_PROJECT_ERROR => 'An expense must have a project.',
        self::ACTIVITY_PROJECT_MISMATCH_ERROR => 'Project mismatch, project specific activity and expense project are different.',
        self::DISABLED_ACTIVITY_ERROR => 'Cannot save expense for a disabled activity.',
        self::DISABLED_PROJECT_ERROR => 'Cannot save expense for a disabled project.',
        self::DISABLED_CUSTOMER_ERROR => 'Cannot save expense for a disabled customer.',
        self::PROJECT_ENDED_ERROR => 'Cannot save expense, project already ended.',
        self::PROJECT_NOT_STARTED_ERROR => 'Cannot save expense, project not yet started.',
    ];

    public string $message = 'This expense has invalid settings.';

    public function getTargets(): string|array
    {
        return self::CLASS_CONSTRAINT;
    }
}
