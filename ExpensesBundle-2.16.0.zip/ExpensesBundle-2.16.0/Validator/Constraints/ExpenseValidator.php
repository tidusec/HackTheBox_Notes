<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Validator\Constraints;

use KimaiPlugin\ExpensesBundle\Entity\Expense as ExpenseEntity;
use KimaiPlugin\ExpensesBundle\Validator\Constraints\Expense as ExpenseConstraint;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;

class ExpenseValidator extends ConstraintValidator
{
    /**
     * @param ExpenseEntity $value
     * @param Constraint $constraint
     * @return void
     */
    public function validate($value, Constraint $constraint): void
    {
        if (!($constraint instanceof ExpenseConstraint)) {
            throw new UnexpectedTypeException($constraint, __NAMESPACE__ . '\Expense');
        }

        if (!\is_object($value) || !($value instanceof ExpenseEntity)) {
            return;
        }

        $this->validateBegin($value, $this->context);
        $this->validateActivityAndProject($value, $this->context);
    }

    protected function validateBegin(ExpenseEntity $expense, ExecutionContextInterface $context): void
    {
        if (null === $expense->getBegin()) {
            $context->buildViolation('You must submit a begin date.')
                ->atPath('begin')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::MISSING_BEGIN_ERROR)
                ->addViolation();

            return;
        }
    }

    protected function validateActivityAndProject(ExpenseEntity $expense, ExecutionContextInterface $context): void
    {
        if (null === ($project = $expense->getProject())) {
            $context->buildViolation('An expense must have a project.')
                ->atPath('project')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::MISSING_PROJECT_ERROR)
                ->addViolation();
        }

        if (null === $project) {
            return;
        }

        if ($project->isVisible() === false) {
            $context->buildViolation('Cannot save expense for a disabled project.')
                ->atPath('project')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::DISABLED_PROJECT_ERROR)
                ->addViolation();
        }

        if ($project->getCustomer()->isVisible() === false) {
            $context->buildViolation('Cannot save expense for a disabled customer.')
                ->atPath('customer')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::DISABLED_CUSTOMER_ERROR)
                ->addViolation();
        }

        if ($project->getStart() !== null && $project->getStart() > $expense->getBegin()) {
            $context->buildViolation(ExpenseConstraint::getErrorName(ExpenseConstraint::PROJECT_NOT_STARTED_ERROR))
                ->atPath('project')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::PROJECT_ENDED_ERROR)
                ->addViolation();
        }

        if ($project->getEnd() !== null && $project->getEnd() < $expense->getBegin()) {
            $context->buildViolation(ExpenseConstraint::getErrorName(ExpenseConstraint::PROJECT_ENDED_ERROR))
                ->atPath('project')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::PROJECT_ENDED_ERROR)
                ->addViolation();
        }

        $activity = $expense->getActivity();
        if (null === $activity) {
            return;
        }

        if (null !== $activity->getProject() && $activity->getProject() !== $project) {
            $context->buildViolation('Project mismatch, project specific activity and expense project are different.')
                ->atPath('project')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::ACTIVITY_PROJECT_MISMATCH_ERROR)
                ->addViolation();
        }

        if ($activity->isVisible() === false) {
            $context->buildViolation('Cannot save expense for a disabled activity.')
                ->atPath('activity')
                ->setTranslationDomain('validators')
                ->setCode(ExpenseConstraint::DISABLED_ACTIVITY_ERROR)
                ->addViolation();
        }
    }
}
