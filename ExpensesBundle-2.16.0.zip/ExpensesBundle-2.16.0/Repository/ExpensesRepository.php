<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Repository;

use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use App\Entity\Team;
use App\Entity\User;
use App\Utils\Pagination;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\ORM\QueryBuilder;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseResult;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;

/**
 * @method null|Expense find($id, $lockMode = null, $lockVersion = null)
 * @extends \Doctrine\ORM\EntityRepository<Expense>
 */
final class ExpensesRepository extends EntityRepository
{
    public function saveExpense(Expense $expense): void
    {
        $entityManager = $this->getEntityManager();
        $entityManager->persist($expense);
        $entityManager->flush();
    }

    public function deleteExpense(Expense $expense): void
    {
        $entityManager = $this->getEntityManager();
        $entityManager->remove($expense);
        $entityManager->flush();
    }

    /**
     * @param array<Expense> $expenses
     * @throws \Exception
     */
    public function deleteMultiple(array $expenses): void
    {
        $em = $this->getEntityManager();
        $em->beginTransaction();

        try {
            foreach ($expenses as $expense) {
                $em->remove($expense);
            }
            $em->flush();
            $em->commit();
        } catch (\Exception $ex) {
            $em->rollback();
            throw $ex;
        }
    }

    /**
     * @param array<Team> $teams
     */
    private function addPermissionCriteria(QueryBuilder $qb, ?User $user = null, array $teams = []): bool
    {
        // make sure that all queries without a user see all projects
        if (null === $user && empty($teams)) {
            return false;
        }

        // make sure that admins see all timesheet records
        if (null !== $user && ($user->isSuperAdmin() || $user->isAdmin())) {
            return false;
        }

        if (null !== $user) {
            $teams = array_merge($teams, $user->getTeams());
        }

        if (empty($teams)) {
            $qb->andWhere('SIZE(c.teams) = 0');
            $qb->andWhere('SIZE(p.teams) = 0');

            return true;
        }

        $orProject = $qb->expr()->orX(
            'SIZE(p.teams) = 0',
            $qb->expr()->isMemberOf(':teams', 'p.teams')
        );
        $qb->andWhere($orProject);

        $orCustomer = $qb->expr()->orX(
            'SIZE(c.teams) = 0',
            $qb->expr()->isMemberOf(':teams', 'c.teams')
        );
        $qb->andWhere($orCustomer);

        $qb->setParameter('teams', $teams);

        return true;
    }

    public function getPagerfantaForQuery(ExpenseQuery $query): Pagination
    {
        return $this->getExpenseResult($query)->getPagerfanta();
    }

    public function getExpenseResult(ExpenseQuery $query): ExpenseResult
    {
        $qb = $this->getQueryBuilderForQuery($query);

        return new ExpenseResult($query, $qb);
    }

    private function getQueryBuilderForQuery(ExpenseQuery $query): QueryBuilder
    {
        $requiresProject = false;
        $requiresCustomer = false;
        $requiresCategory = false;

        $qb = $this->getEntityManager()->createQueryBuilder();

        $qb
            ->select('e')
            ->from(Expense::class, 'e')
        ;

        /** @var array<int|User> $user */
        $user = [];

        if (null !== $query->getUser()) {
            $user[] = $query->getUser();
        }

        $user = array_merge($user, $query->getUsers());

        if (empty($user) && null !== $query->getCurrentUser()) {
            $currentUser = $query->getCurrentUser();

            if (!$currentUser->canSeeAllData()) {
                // make sure that the user is in the list of users, if he is part of a team
                // if teams are used and the user is not a teamlead, the list of users would be empty and
                // then leading to NOT limit the select by user IDs
                $user[] = $currentUser;

                if (\count($query->getTeams()) === 0) {
                    foreach ($currentUser->getTeams() as $team) {
                        if ($currentUser->isTeamleadOf($team)) {
                            $query->addTeam($team);
                        }
                    }
                }
            }
        }

        foreach ($query->getTeams() as $team) {
            foreach ($team->getUsers() as $teamUser) {
                $user[] = $teamUser;
            }
        }

        $user = array_unique(array_map(function ($user) {
            if ($user instanceof User) {
                return $user->getId();
            }

            return $user;
        }, $user));

        if (!empty($user)) {
            $qb->andWhere($qb->expr()->in('e.user', $user));
        }

        if (null !== $query->getBegin()) {
            $qb->andWhere('e.begin >= :begin')
                ->setParameter('begin', $query->getBegin());
        }

        if (null !== $query->getEnd()) {
            $qb->andWhere('e.begin <= :end')
                ->setParameter('end', $query->getEnd());
        }

        if (!$query->isIgnoreBillable()) {
            $qb->andWhere('e.refundable = :refundable')
                ->setParameter('refundable', $query->isBillable(), Types::BOOLEAN);
        }

        if (!$query->isIgnoreExported()) {
            $qb->andWhere('e.exported = :exported')
                ->setParameter('exported', $query->isExported(), Types::BOOLEAN);
        }

        if ($query->hasActivities()) {
            $qb->andWhere($qb->expr()->in('e.activity', ':activity'))
                ->setParameter('activity', $query->getActivities());
        }

        if ($query->hasProjects()) {
            $requiresProject = true;
            $qb->andWhere($qb->expr()->in('e.project', ':project'))
                ->setParameter('project', $query->getProjects());
        } elseif ($query->hasCustomers()) {
            $requiresCustomer = true;
            $qb->andWhere($qb->expr()->in('p.customer', ':customer'))
                ->setParameter('customer', $query->getCustomers());
        }

        if (null !== $query->getCategory()) {
            $requiresCategory = true;
            $qb->andWhere('e.category = :category')
                ->setParameter('category', $query->getCategory());
        }

        $requiresTeams = $this->addPermissionCriteria($qb, $query->getCurrentUser(), $query->getTeams());

        $orderBy = $query->getOrderBy();
        switch ($orderBy) {
            case 'project':
                $requiresProject = true;
                $orderBy = 'p.name';
                break;
            case 'customer':
                $requiresCustomer = true;
                $orderBy = 'c.name';
                break;
            case 'activity':
                $qb->leftJoin('e.activity', 'a');
                $orderBy = 'a.name';
                break;
            case 'user':
                $qb->leftJoin('e.user', 'u');
                $orderBy = 'u.username';
                break;
            case 'total':
                $qb->addSelect('e.cost * e.multiplier as HIDDEN total');
                $orderBy = 'total';
                break;
            case 'category':
                $requiresCategory = true;
                $orderBy = 'cat.name';
                break;
            default:
                $orderBy = 'e.' . $orderBy;
                break;
        }

        $qb->addOrderBy($orderBy, $query->getOrder());

        $searchTerm = $query->getSearchTerm();
        if ($searchTerm !== null) {
            $searchAnd = $qb->expr()->andX();

            foreach ($searchTerm->getSearchFields() as $metaName => $metaValue) {
                $qb->leftJoin('e.meta', 'meta');
                $searchAnd->add(
                    $qb->expr()->andX(
                        $qb->expr()->eq('meta.name', ':metaName'),
                        $qb->expr()->like('meta.value', ':metaValue')
                    )
                );
                $qb->setParameter('metaName', $metaName);
                $qb->setParameter('metaValue', '%' . $metaValue . '%');
            }

            if ($searchTerm->hasSearchTerm()) {
                $searchAnd->add(
                    $qb->expr()->like('e.description', ':searchTerm')
                );
                $qb->setParameter('searchTerm', '%' . $searchTerm->getSearchTerm() . '%');
            }

            if ($searchAnd->count() > 0) {
                $qb->andWhere($searchAnd);
            }
        }

        if ($requiresCustomer || $requiresProject || $requiresTeams) {
            $qb->leftJoin('e.project', 'p');
        }

        if ($requiresCustomer || $requiresTeams) {
            $qb->leftJoin('p.customer', 'c');
        }

        if ($requiresCategory) {
            $qb->leftJoin('e.category', 'cat');
        }

        return $qb;
    }

    /**
     * @param Expense[] $expenses
     */
    public function setExported(array $expenses): void
    {
        $ids = array_map(function (Expense $expense) {
            return $expense->getId();
        }, $expenses);

        if (empty($ids)) {
            return;
        }

        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->update(Expense::class, 'e')
            ->set('e.exported', ':exported')
            ->where($qb->expr()->in('e.id', ':ids'))
            ->setParameter('exported', true, Types::BOOLEAN)
            ->setParameter('ids', $ids)
            ->getQuery()
            ->execute();
    }

    /**
     * @return array<string, int|float>
     */
    public function getCustomerStatistic(Customer $customer, ?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null): array
    {
        $result = $this->getCustomerStatistics([$customer], $begin, $end);

        return array_pop($result);
    }

    /**
     * @param Customer[] $customers
     * @return array<int, array<string, int|float>>
     */
    public function getCustomerStatistics(array $customers, ?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null): array
    {
        $statistics = [];
        $ids = [];

        foreach ($customers as $customer) {
            $ids[] = $customer->getId();
            $statistics[$customer->getId()] = [
                'amount' => 0,
                'amount_exported' => 0,
                'rate' => 0.0,
                'rate_exported' => 0.0,
                'refundable' => 0.0,
                'refundable_exported' => 0.0,
            ];
        }

        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->join(Project::class, 'p', Join::WITH, 'e.project = p.id')
            ->addSelect('IDENTITY(p.customer) as customer')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.refundable as refundable')
            ->addSelect('e.exported as exported')
            ->andWhere('p.customer = :customer')
            ->setParameter('customer', $ids)
            ->addGroupBy('p.customer')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        if ($begin !== null) {
            $begin = \DateTimeImmutable::createFromInterface($begin);
            $qb
                ->andWhere($qb->expr()->gte('e.begin', ':begin'))
                ->setParameter('begin', $begin, Types::DATETIME_IMMUTABLE)
            ;
        }

        if ($end !== null) {
            $end = \DateTimeImmutable::createFromInterface($end);
            $qb
                ->andWhere($qb->expr()->lte('e.begin', ':end'))
                ->setParameter('end', $end, Types::DATETIME_IMMUTABLE)
            ;
        }

        $results = $qb->getQuery()->getResult();

        foreach ($results as $result) {
            $id = $result['customer'];
            $statistics[$id]['amount'] += $result['amount'];
            $statistics[$id]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$id]['refundable'] += (float) $result['rate'];
            }
            if ($result['exported']) {
                $statistics[$id]['amount_exported'] += $result['amount'];
                $statistics[$id]['rate_exported'] += (float) $result['rate'];
                if ($result['refundable']) {
                    $statistics[$id]['refundable_exported'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }

    /**
     * @return array<string, int|float>
     */
    public function getProjectStatistic(Project $project, ?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null): array
    {
        $result = $this->getProjectStatistics([$project], $begin, $end);

        return array_pop($result);
    }

    /**
     * @param Project[] $projects
     * @return array<int, array<string, int|float>>
     */
    public function getProjectStatistics(array $projects, ?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null): array
    {
        $statistics = [];
        $ids = [];

        foreach ($projects as $project) {
            $ids[] = $project->getId();
            $statistics[$project->getId()] = [
                'amount' => 0,
                'amount_exported' => 0,
                'rate' => 0.0,
                'rate_exported' => 0.0,
                'refundable' => 0.0,
                'refundable_exported' => 0.0,
            ];
        }

        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->addSelect('IDENTITY(e.project) as project')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.refundable as refundable')
            ->addSelect('e.exported as exported')
            ->andWhere($qb->expr()->in('e.project', ':project'))
            ->setParameter('project', $ids)
            ->addGroupBy('e.project')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        if ($begin !== null) {
            $begin = \DateTimeImmutable::createFromInterface($begin);
            $qb
                ->andWhere($qb->expr()->gte('e.begin', ':begin'))
                ->setParameter('begin', $begin, Types::DATETIME_IMMUTABLE)
            ;
        }

        if ($end !== null) {
            $end = \DateTimeImmutable::createFromInterface($end);
            $qb
                ->andWhere($qb->expr()->lte('e.begin', ':end'))
                ->setParameter('end', $end, Types::DATETIME_IMMUTABLE)
            ;
        }

        $results = $qb->getQuery()->getResult();

        foreach ($results as $result) {
            $id = $result['project'];
            $statistics[$id]['amount'] += $result['amount'];
            $statistics[$id]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$id]['refundable'] += (float) $result['rate'];
            }
            if ($result['exported']) {
                $statistics[$id]['amount_exported'] += $result['amount'];
                $statistics[$id]['rate_exported'] += (float) $result['rate'];
                if ($result['refundable']) {
                    $statistics[$id]['refundable_exported'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }

    /**
     * @return array<string, int|float>
     */
    public function getActivityStatistic(Activity $activity, ?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null): array
    {
        $result = $this->getActivityStatistics([$activity], $begin, $end);

        return array_pop($result);
    }

    /**
     * @param Activity[] $activities
     * @return array<int, array<string, int|float>>
     */
    public function getActivityStatistics(array $activities, ?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null): array
    {
        $statistics = [];
        $ids = [];

        foreach ($activities as $activity) {
            $ids[] = $activity->getId();
            $statistics[$activity->getId()] = [
                'amount' => 0,
                'amount_exported' => 0,
                'rate' => 0.0,
                'rate_exported' => 0.0,
                'refundable' => 0.0,
                'refundable_exported' => 0.0,
            ];
        }

        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->addSelect('IDENTITY(e.activity) as activity')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.refundable as refundable')
            ->addSelect('e.exported as exported')
            ->andWhere($qb->expr()->in('e.activity', ':activity'))
            ->setParameter('activity', $ids)
            ->addGroupBy('e.activity')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        if ($begin !== null) {
            $begin = \DateTimeImmutable::createFromInterface($begin);
            $qb
                ->andWhere($qb->expr()->gte('e.begin', ':begin'))
                ->setParameter('begin', $begin, Types::DATETIME_IMMUTABLE)
            ;
        }

        if ($end !== null) {
            $end = \DateTimeImmutable::createFromInterface($end);
            $qb
                ->andWhere($qb->expr()->lte('e.begin', ':end'))
                ->setParameter('end', $end, Types::DATETIME_IMMUTABLE)
            ;
        }

        $results = $qb->getQuery()->getResult();

        foreach ($results as $result) {
            $id = $result['activity'];
            $statistics[$id]['amount'] += $result['amount'];
            $statistics[$id]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$id]['refundable'] += (float) $result['rate'];
            }
            if ($result['exported']) {
                $statistics[$id]['amount_exported'] += $result['amount'];
                $statistics[$id]['rate_exported'] += (float) $result['rate'];
                if ($result['refundable']) {
                    $statistics[$id]['refundable_exported'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }

    /**
     * @return array<string, array<string, int|float>>
     */
    public function getStatistics(?\DateTimeInterface $begin = null, ?\DateTimeInterface $end = null, ?User $user = null): array
    {
        $statistics = [];

        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.refundable as refundable')
            ->addSelect('e.exported as exported')
            ->addSelect('c.currency')
            ->leftJoin('e.project', 'p')
            ->leftJoin('p.customer', 'c')
            ->groupBy('c.currency')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        if ($begin !== null) {
            $begin = \DateTimeImmutable::createFromInterface($begin);
            $end = \DateTimeImmutable::createFromInterface($end);
            $qb->andWhere($qb->expr()->between('e.begin', ':begin', ':end'))
                ->setParameter('begin', $begin, Types::DATETIME_IMMUTABLE)
                ->setParameter('end', $end, Types::DATETIME_IMMUTABLE);
        }

        if ($user !== null) {
            $qb->andWhere($qb->expr()->eq('e.user', ':user'))
                ->setParameter('user', $user->getId());
        }

        $results = $qb->getQuery()->getArrayResult();

        foreach ($results as $result) {
            $currency = $result['currency'];
            if (!\array_key_exists($currency, $statistics)) {
                $statistics[$currency] = [
                    'amount' => 0,
                    'amount_exported' => 0,
                    'rate' => 0.0,
                    'rate_exported' => 0.0,
                    'refundable' => 0.0,
                    'refundable_exported' => 0.0,
                ];
            }
            $statistics[$currency]['amount'] += $result['amount'];
            $statistics[$currency]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$currency]['refundable'] += (float) $result['rate'];
            }
            if ($result['exported']) {
                $statistics[$currency]['amount_exported'] += $result['amount'];
                $statistics[$currency]['rate_exported'] += (float) $result['rate'];
                if ($result['refundable']) {
                    $statistics[$currency]['refundable_exported'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }

    public function deleteUser(User $delete, ?User $replace = null): void
    {
        $em = $this->getEntityManager();
        $em->beginTransaction();

        try {
            if (null !== $replace) {
                $qb = $em->createQueryBuilder();
                $qb
                    ->update(Expense::class, 'e')
                    ->set('e.user', ':replace')
                    ->where('e.user = :delete')
                    ->setParameter('delete', $delete->getId())
                    ->setParameter('replace', $replace->getId())
                    ->getQuery()
                    ->execute();
            }

            $em->flush();
            $em->commit();
        } catch (\Exception $ex) {
            $em->rollback();
            throw $ex;
        }
    }
}
