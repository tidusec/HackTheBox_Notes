<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Repository;

use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use App\Repository\Paginator\LoaderPaginator;
use App\Repository\Paginator\PaginatorInterface;
use App\Utils\Pagination;
use Doctrine\DBAL\ParameterType;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\ORMException;
use Doctrine\ORM\QueryBuilder;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use KimaiPlugin\ExpensesBundle\Repository\Loader\ExpenseCategoryLoader;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;

/**
 * @extends \Doctrine\ORM\EntityRepository<ExpenseCategory>
 */
final class ExpensesCategoryRepository extends EntityRepository
{
    public function saveCategory(ExpenseCategory $category): void
    {
        $entityManager = $this->getEntityManager();
        $entityManager->persist($category);
        $entityManager->flush();
    }

    public function deleteCategory(ExpenseCategory $category, ?ExpenseCategory $replacement = null): void
    {
        $em = $this->getEntityManager();
        $em->beginTransaction();

        try {
            if (null !== $replacement) {
                $qb = $em->createQueryBuilder();
                $qb
                    ->update(Expense::class, 'e')
                    ->set('e.category', ':replace')
                    ->where('e.category = :delete')
                    ->setParameter('delete', $category)
                    ->setParameter('replace', $replacement)
                    ->getQuery()
                    ->execute();
            }

            $em->remove($category);
            $em->flush();
            $em->commit();
        } catch (ORMException $ex) {
            $em->rollback();
            throw $ex;
        }
    }

    public function getPagerfantaForQuery(ExpenseQuery $query): Pagination
    {
        return new Pagination($this->getPaginatorForQuery($query), $query);
    }

    public function getQueryBuilderForFormType(): QueryBuilder
    {
        $qb = $this->getEntityManager()->createQueryBuilder();

        $qb->select('c')
            ->from(ExpenseCategory::class, 'c')
            ->andWhere('c.visible = :visible')
            ->setParameter('visible', true, ParameterType::BOOLEAN)
            ->orderBy('c.name', 'ASC')
        ;

        return $qb;
    }

    protected function getPaginatorForQuery(ExpenseQuery $query): PaginatorInterface
    {
        $qb = $this->getQueryBuilderForQuery($query);
        $qb
            ->resetDQLPart('select')
            ->resetDQLPart('orderBy')
            ->select($qb->expr()->countDistinct('c.id'))
        ;
        $counter = (int) $qb->getQuery()->getSingleScalarResult();

        $qb = $this->getQueryBuilderForQuery($query);

        return new LoaderPaginator(new ExpenseCategoryLoader(), $qb, $counter);
    }

    public function countUsage(ExpenseCategory $category): int
    {
        $qb = $this->getEntityManager()->createQueryBuilder();

        $qb->select($qb->expr()->count('e.id'))
            ->from(Expense::class, 'e')
            ->andWhere('e.category = :category')
            ->setParameter('category', $category)
        ;

        return (int) $qb->getQuery()->getSingleScalarResult();
    }

    private function getQueryBuilderForQuery(ExpenseQuery $query): QueryBuilder
    {
        $qb = $this->getEntityManager()->createQueryBuilder();

        $qb
            ->select('c')
            ->from(ExpenseCategory::class, 'c')
            ->addOrderBy('c.name', 'ASC')
        ;

        return $qb;
    }

    public function hasVisibleCategory(): bool
    {
        return $this->count(['visible' => true]) > 0;
    }

    /**
     * @param Customer $customer
     * @return array<int, array<string, int|float>>
     */
    public function getCustomerStatistic(Customer $customer): array
    {
        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->leftJoin('e.category', 'c')
            ->leftJoin('e.project', 'p')
            ->addSelect('IDENTITY(p.customer) as customer')
            ->addSelect('IDENTITY(e.category) as category')
            ->addSelect('c.name as name')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.exported as exported')
            ->addSelect('e.refundable as refundable')
            ->andWhere($qb->expr()->eq('p.customer', ':customer'))
            ->setParameter('customer', $customer->getId())
            ->addGroupBy('p.customer')
            ->addGroupBy('e.category')
            ->addGroupBy('c.name')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        $results = $qb->getQuery()->getResult();

        $statistics = [];
        foreach ($results as $result) {
            $cid = $result['category'];
            if (!\array_key_exists($cid, $statistics)) {
                $statistics[$cid] = [
                    'category' => $result['name'],
                    'id' => $cid,
                    'amount' => 0,
                    'rate' => 0.0,
                    'refundable' => 0.0,
                    'open' => 0.0,
                ];
            }
            $statistics[$cid]['amount'] += $result['amount'];
            $statistics[$cid]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$cid]['refundable'] += (float) $result['rate'];
                if (!$result['exported']) {
                    $statistics[$cid]['open'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }

    /**
     * @param Project $project
     * @return array<int, array<string, int|float>>
     */
    public function getProjectStatistic(Project $project): array
    {
        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->leftJoin('e.category', 'c')
            ->addSelect('IDENTITY(e.project) as project')
            ->addSelect('IDENTITY(e.category) as category')
            ->addSelect('c.name')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.exported as exported')
            ->addSelect('e.refundable as refundable')
            ->andWhere($qb->expr()->eq('e.project', ':project'))
            ->setParameter('project', $project->getId())
            ->addGroupBy('e.project')
            ->addGroupBy('e.category')
            ->addGroupBy('c.name')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        $results = $qb->getQuery()->getResult();

        $statistics = [];
        foreach ($results as $result) {
            $cid = $result['category'];
            if (!\array_key_exists($cid, $statistics)) {
                $statistics[$cid] = [
                    'category' => $result['name'],
                    'id' => $cid,
                    'amount' => 0,
                    'rate' => 0.0,
                    'refundable' => 0.0,
                    'open' => 0.0,
                ];
            }
            $statistics[$cid]['amount'] += $result['amount'];
            $statistics[$cid]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$cid]['refundable'] += (float) $result['rate'];
                if (!$result['exported']) {
                    $statistics[$cid]['open'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }

    /**
     * @param Activity $activity
     * @return array<int, array<string, int|float>>
     */
    public function getActivityStatistic(Activity $activity): array
    {
        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->from(Expense::class, 'e')
            ->leftJoin('e.category', 'c')
            ->addSelect('IDENTITY(e.activity) as activity')
            ->addSelect('IDENTITY(e.category) as category')
            ->addSelect('c.name')
            ->addSelect('COUNT(e.id) as amount')
            ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
            ->addSelect('e.exported as exported')
            ->addSelect('e.refundable as refundable')
            ->andWhere($qb->expr()->eq('e.activity', ':activity'))
            ->setParameter('activity', $activity->getId())
            ->addGroupBy('e.activity')
            ->addGroupBy('e.category')
            ->addGroupBy('c.name')
            ->addGroupBy('e.refundable')
            ->addGroupBy('e.exported')
        ;

        $results = $qb->getQuery()->getResult();

        $statistics = [];
        foreach ($results as $result) {
            $cid = $result['category'];
            if (!\array_key_exists($cid, $statistics)) {
                $statistics[$cid] = [
                    'category' => $result['name'],
                    'id' => $cid,
                    'amount' => 0,
                    'rate' => 0.0,
                    'refundable' => 0.0,
                    'open' => 0.0,
                ];
            }
            $statistics[$cid]['amount'] += $result['amount'];
            $statistics[$cid]['rate'] += (float) $result['rate'];
            if ($result['refundable']) {
                $statistics[$cid]['refundable'] += (float) $result['rate'];
                if (!$result['exported']) {
                    $statistics[$cid]['open'] += (float) $result['rate'];
                }
            }
        }

        return $statistics;
    }
}
