<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Repository\Query;

use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use App\Entity\User;
use App\Form\Model\DateRange;
use App\Repository\Query\BaseQuery;
use App\Repository\Query\BillableInterface;
use App\Repository\Query\BillableTrait;
use App\Repository\Query\TimesheetQuery;
use App\Repository\Query\VisibilityInterface;
use App\Repository\Query\VisibilityTrait;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;

final class ExpenseQuery extends BaseQuery implements VisibilityInterface, BillableInterface
{
    use BillableTrait;
    use VisibilityTrait;

    public const EXPENSES_ORDER_ALLOWED = [
        'date' => 'begin',
        // 'end',
        'duration',
        'amount' => 'multiplier',
        'expense' => 'cost',
        'sum.total' => 'total',
        'category',
        'user',
        'customer',
        'project',
        'activity',
        'description',
        'exported',
        'billable' => 'refundable',
    ];

    /**
     * @var array<Customer|int>
     */
    private array $customers = [];
    /**
     * @var Project[]
     */
    private array $projects = [];
    /**
     * @var array<Activity>
     */
    private array $activities = [];
    /**
     * @var ExpenseCategory|null
     */
    private ?ExpenseCategory $category = null;
    private int $exported = TimesheetQuery::STATE_ALL;
    private DateRange $dateRange;
    /**
     * @var User[]
     */
    private array $users = [];
    private ?User $user = null;

    public function __construct()
    {
        $this->setDefaults([
            'order' => self::ORDER_DESC,
            'orderBy' => 'begin',
            'customers' => [],
            'projects' => [],
            'activities' => [],
            'category' => null,
            'exported' => TimesheetQuery::STATE_ALL,
            'users' => [],
            'dateRange' => new DateRange(),
            'billable' => null,
            'visibility' => VisibilityInterface::SHOW_BOTH,
        ]);
    }

    public function addUser(User $user): ExpenseQuery
    {
        $this->users[$user->getId()] = $user;

        return $this;
    }

    public function removeUser(User $user): ExpenseQuery
    {
        if (isset($this->users[$user->getId()])) {
            unset($this->users[$user->getId()]);
        }

        return $this;
    }

    /**
     * @return User[]
     */
    public function getUsers(): array
    {
        return array_values($this->users);
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(User $user): ExpenseQuery
    {
        $this->user = $user;

        return $this;
    }

    /**
     * @return array<Activity>
     */
    public function getActivities(): array
    {
        return $this->activities;
    }

    /**
     * @param Activity $activity
     * @return $this
     */
    public function addActivity(Activity $activity)
    {
        $this->activities[] = $activity;

        return $this;
    }

    /**
     * @param array<Activity> $activities
     * @return $this
     */
    public function setActivities(array $activities)
    {
        $this->activities = $activities;

        return $this;
    }

    public function hasActivities(): bool
    {
        return !empty($this->activities);
    }

    /**
     * @param Customer $customer
     * @return $this
     */
    public function addCustomer(Customer $customer)
    {
        $this->customers[] = $customer;

        return $this;
    }

    /**
     * @param array<Customer> $customers
     * @return $this
     */
    public function setCustomers(array $customers): ExpenseQuery
    {
        $this->customers = $customers;

        return $this;
    }

    /**
     * @return array<Customer>
     */
    public function getCustomers(): array
    {
        return $this->customers;
    }

    public function hasCustomers(): bool
    {
        return !empty($this->customers);
    }

    /**
     * @param Project[] $projects
     * @return ExpenseQuery
     */
    public function setProjects(array $projects): ExpenseQuery
    {
        $this->projects = $projects;

        return $this;
    }

    public function addProject(Project $project): ExpenseQuery
    {
        $this->projects[] = $project;

        return $this;
    }

    /**
     * @return Project[]
     */
    public function getProjects(): array
    {
        return $this->projects;
    }

    public function hasProjects(): bool
    {
        return !empty($this->projects);
    }

    public function getCategory(): ?ExpenseCategory
    {
        return $this->category;
    }

    public function setCategory(?ExpenseCategory $category): ExpenseQuery
    {
        $this->category = $category;

        return $this;
    }

    public function isExported(): bool
    {
        return $this->exported === TimesheetQuery::STATE_EXPORTED;
    }

    public function isIgnoreExported(): bool
    {
        return $this->exported === TimesheetQuery::STATE_ALL;
    }

    public function isNotExported(): bool
    {
        return $this->exported === TimesheetQuery::STATE_NOT_EXPORTED;
    }

    public function getExported(): int
    {
        return $this->exported;
    }

    public function setExported(int $exported): ExpenseQuery
    {
        if (\in_array($exported, [TimesheetQuery::STATE_ALL, TimesheetQuery::STATE_EXPORTED, TimesheetQuery::STATE_NOT_EXPORTED], true)) {
            $this->exported = $exported;
        }

        return $this;
    }

    public function getBegin(): ?\DateTime
    {
        return $this->dateRange->getBegin();
    }

    public function setBegin(\DateTime $begin): ExpenseQuery
    {
        $this->dateRange->setBegin($begin);

        return $this;
    }

    public function getEnd(): ?\DateTime
    {
        return $this->dateRange->getEnd();
    }

    public function setEnd(\DateTime $end): ExpenseQuery
    {
        $this->dateRange->setEnd($end);

        return $this;
    }

    public function getDateRange(): DateRange
    {
        return $this->dateRange;
    }

    public function setDateRange(DateRange $dateRange): ExpenseQuery
    {
        $this->dateRange = $dateRange;

        return $this;
    }
}
