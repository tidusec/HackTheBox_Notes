<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Repository\Loader;

use App\Entity\Project;
use App\Repository\Loader\LoaderInterface;
use Doctrine\ORM\EntityManagerInterface;
use KimaiPlugin\ExpensesBundle\Entity\Expense;

final class ExpenseIdLoader implements LoaderInterface
{
    public function __construct(private EntityManagerInterface $entityManager)
    {
    }

    /**
     * @param int[] $results
     */
    public function loadResults(array $results): void
    {
        if (empty($results)) {
            return;
        }

        $em = $this->entityManager;

        $qb = $em->createQueryBuilder();
        $projects = $qb->select('PARTIAL e.{id}', 'project')
            ->from(Expense::class, 'e')
            ->leftJoin('e.project', 'project')
            ->andWhere($qb->expr()->in('e.id', $results))
            ->getQuery()
            ->execute();

        $qb = $em->createQueryBuilder();
        $qb->select('PARTIAL e.{id}', 'meta')
            ->from(Expense::class, 'e')
            ->leftJoin('e.meta', 'meta')
            ->andWhere($qb->expr()->in('e.id', $results))
            ->getQuery()
            ->execute();

        if (!empty($projects)) {
            $projectIds = array_map(function (Expense $expense) {
                return $expense->getProject()->getId();
            }, $projects);

            $qb = $em->createQueryBuilder();
            $qb->select('PARTIAL p.{id}', 'customer')
                ->from(Project::class, 'p')
                ->leftJoin('p.customer', 'customer')
                ->andWhere($qb->expr()->in('p.id', $projectIds))
                ->getQuery()
                ->execute();
        }

        $qb = $em->createQueryBuilder();
        $qb->select('PARTIAL e.{id}', 'activity')
            ->from(Expense::class, 'e')
            ->leftJoin('e.activity', 'activity')
            ->andWhere($qb->expr()->in('e.id', $results))
            ->getQuery()
            ->execute();

        $qb = $em->createQueryBuilder();
        $qb->select('PARTIAL e.{id}', 'user')
            ->from(Expense::class, 'e')
            ->leftJoin('e.user', 'user')
            ->andWhere($qb->expr()->in('e.id', $results))
            ->getQuery()
            ->execute();

        $qb = $em->createQueryBuilder();
        $qb->select('PARTIAL e.{id}', 'category')
            ->from(Expense::class, 'e')
            ->leftJoin('e.category', 'category')
            ->andWhere($qb->expr()->in('e.id', $results))
            ->getQuery()
            ->execute();
    }
}
