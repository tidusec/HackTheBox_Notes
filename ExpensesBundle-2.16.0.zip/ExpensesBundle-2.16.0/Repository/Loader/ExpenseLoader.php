<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Repository\Loader;

use App\Repository\Loader\LoaderInterface;
use Doctrine\ORM\EntityManagerInterface;
use KimaiPlugin\ExpensesBundle\Entity\Expense;

final class ExpenseLoader implements LoaderInterface
{
    /**
     * @var ExpenseIdLoader
     */
    private $loader;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->loader = new ExpenseIdLoader($entityManager);
    }

    /**
     * @param Expense[] $expenses
     */
    public function loadResults(array $expenses): void
    {
        $ids = array_map(function (Expense $expense) {
            return $expense->getId();
        }, $expenses);

        $this->loader->loadResults($ids);
    }
}
