<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Repository;

use App\Entity\ExportableItem;
use App\Export\ExportRepositoryInterface;
use App\Repository\Query\ExportQuery;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;

final class ExpensesExportRepository implements ExportRepositoryInterface
{
    /**
     * @var ExpensesRepository
     */
    private $repository;

    public function __construct(ExpensesRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param ExportableItem[] $items
     * @return void
     */
    public function setExported(array $items): void
    {
        $expenses = [];

        foreach ($items as $item) {
            if ($item instanceof Expense) {
                $expenses[] = $item;
            }
        }

        $this->repository->setExported($expenses);
    }

    /**
     * @param ExportQuery $query
     * @return ExportableItem[]
     */
    public function getExportItemsForQuery(ExportQuery $query): iterable
    {
        $expenseQuery = new ExpenseQuery();

        // from invoice query
        $expenseQuery
            ->setCustomers($query->getCustomers())
            ->setProjects($query->getProjects())
            ->setActivities($query->getActivities())
            ->setExported($query->getExported())
            ->setDateRange($query->getDateRange())
        ;

        if (!$query->isIgnoreBillable()) {
            $expenseQuery->setBillable($query->isBillable());
        }

        if (null !== $query->getUser()) {
            $expenseQuery->setUser($query->getUser());
        }

        foreach ($query->getTeams() as $team) {
            $expenseQuery->addTeam($team);
        }

        // from base query
        $expenseQuery
            ->setPage($query->getPage())
            ->setPageSize($query->getPageSize())
            ->setSearchTerm($query->getSearchTerm())
            ->setOrderBy($query->getOrderBy())
            ->setOrder($query->getOrder())
        ;

        // might be null if called from anonymous context (eg. bash scripts)
        if (null !== $query->getCurrentUser()) {
            $expenseQuery->setCurrentUser($query->getCurrentUser());
        }

        foreach ($query->getUsers() as $user) {
            $expenseQuery->addUser($user);
        }

        foreach ($query->getTeams() as $team) {
            $expenseQuery->addTeam($team);
        }

        return $this->repository->getExpenseResult($expenseQuery)->getResults();
    }

    public function getType(): string
    {
        return 'expense';
    }
}
