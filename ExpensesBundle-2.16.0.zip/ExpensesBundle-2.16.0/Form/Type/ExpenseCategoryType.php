<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Form\Type;

use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesCategoryRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ExpenseCategoryType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'documentation' => [
                'type' => 'integer',
                'description' => 'Expense-Category ID',
            ],
            'label' => 'category',
            'class' => ExpenseCategory::class,
            'choice_label' => function (ExpenseCategory $category) {
                $label = $category->getName();
                if (!empty($category->getHelp())) {
                    $label .= ' (' . $category->getHelp() . ')';
                }

                return $label;
            },
            'choice_attr' => function (ExpenseCategory $category) {
                return ['data-description' => $category->getDescription()];
            },
            'query_builder' => function (ExpensesCategoryRepository $repository) {
                return $repository->getQueryBuilderForFormType();
            }
        ]);
    }

    public function getParent(): string
    {
        return EntityType::class;
    }
}
