<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Form\Extension;

use App\Form\Helper\ToolbarHelper;
use KimaiPlugin\ExpensesBundle\Form\ExpenseToolbarForm;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\FormBuilderInterface;

final class ExpenseToolbarFormExtension extends AbstractTypeExtension
{
    public function __construct(private ToolbarHelper $toolbarHelper)
    {
    }

    public static function getExtendedTypes(): iterable
    {
        return [ExpenseToolbarForm::class];
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $this->toolbarHelper->cleanupForm($builder);
    }
}
