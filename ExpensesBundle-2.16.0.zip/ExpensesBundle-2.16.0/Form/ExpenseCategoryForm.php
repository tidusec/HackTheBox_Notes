<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Form;

use App\Form\EntityFormTrait;
use App\Form\Type\YesNoType;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;

class ExpenseCategoryForm extends AbstractType
{
    use EntityFormTrait;

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $currency = $options['currency'];

        $builder->add('name', TextType::class, [
            'label' => 'name',
        ]);
        $this->addColor($builder);
        $builder->add('help', TextType::class, [
            'label' => 'help',
            'help' => 'help.help',
            'required' => false,
            'constraints' => [
                new Length(['max' => 100])
            ],
        ]);
        $builder->add('description', TextareaType::class, [
            'label' => 'description',
            'required' => false,
            'help' => 'help.expense_description'
        ]);
        $builder->add('cost', MoneyType::class, [
            'label' => 'expense',
            'currency' => $currency,
            'required' => false,
            'help' => 'help.category_cost'
        ]);
        $builder->add('visible', YesNoType::class, [
            'label' => 'visible',
        ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => ExpenseCategory::class,
            'csrf_protection' => true,
            'csrf_field_name' => '_token',
            'csrf_token_id' => 'expense_category_edit',
            'method' => 'POST',
            'currency' => null,
            'attr' => [
                'data-form-event' => 'kimai.expenseCategoryUpdate',
                'data-msg-success' => 'action.update.success',
                'data-msg-error' => 'action.update.error',
            ],
        ]);
    }
}
