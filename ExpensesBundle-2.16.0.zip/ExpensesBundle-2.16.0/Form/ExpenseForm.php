<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Form;

use App\Configuration\SystemConfiguration;
use App\Entity\Timesheet;
use App\Form\FormTrait;
use App\Form\Type\DatePickerType;
use App\Form\Type\DateTimePickerType;
use App\Form\Type\MetaFieldsCollectionType;
use App\Form\Type\TimesheetBillableType;
use App\Form\Type\UserType;
use App\Form\Type\YesNoType;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Form\Type\ExpenseCategoryType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\CallbackTransformer;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ExpenseForm extends AbstractType
{
    use FormTrait;

    public function __construct(private readonly SystemConfiguration $systemConfiguration)
    {
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $activity = null;
        $project = null;
        $customer = null;
        $isNew = true;
        $currency = $options['currency'];
        $timezone = $options['timezone'];

        if (isset($options['data'])) {
            /** @var Expense $entry */
            $entry = $options['data'];

            $activity = $entry->getActivity();
            $project = $entry->getProject();
            $customer = $project?->getCustomer();

            if (null !== $entry->getId()) {
                $isNew = false;
            }

            if (null === $project && null !== $activity) {
                $project = $activity->getProject();
            }

            if (null !== $customer) {
                $currency = $customer->getCurrency();
            }

            if (null !== ($begin = $entry->getBegin())) {
                $timezone = $begin->getTimezone()->getName();
            }
        }

        $this->addBegin($builder, [
            'model_timezone' => $timezone,
            'view_timezone' => $timezone,
            'label' => 'date',
        ]);

        if ($options['include_user']) {
            $builder->add('user', UserType::class);
        }

        $this->addCustomer($builder, $customer);
        $this->addProject($builder, $isNew, $project, $customer);
        $this->addActivity($builder, $activity, $project, ['required' => false]);
        $builder->add('expenseCategory', ExpenseCategoryType::class, [
            'required' => true,
        ]);
        $builder->add('description', TextareaType::class, [
            'documentation' => [
                'type' => 'string',
                'description' => 'Description for the expense',
            ],
            'label' => 'description',
            'required' => false,
        ]);

        if ($options['include_cost']) {
            $builder->add('cost', MoneyType::class, [
                'documentation' => [
                    'type' => 'number',
                    'description' => 'Cost per entry (multiplied by multiplier). This field is not available to every user.',
                ],
                'label' => 'expense',
                'required' => false,
                'currency' => $currency,
            ]);
        }

        $builder->add('multiplier', NumberType::class, [
            'label' => 'amount',
        ]);

        $builder->add('metaFields', MetaFieldsCollectionType::class);

        $builder->add('billableMode', TimesheetBillableType::class, [
            'required' => true,
        ]);

        if ($options['include_exported']) {
            $builder->add('exported', YesNoType::class, [
                'label' => 'exported'
            ]);
        }

        $builder->addModelTransformer(
            new CallbackTransformer(
                function ($expense) {
                    if ($expense instanceof Expense) {
                        if ($expense->getId() === null) {
                            $expense->setBillableMode(Timesheet::BILLABLE_AUTOMATIC);
                        } elseif ($expense->isRefundable()) {
                            $expense->setBillableMode(Timesheet::BILLABLE_YES);
                        } else {
                            $expense->setBillableMode(Timesheet::BILLABLE_NO);
                        }
                    }

                    return $expense;
                },
                function (?Expense $expense) use ($options) {
                    if (null === $expense) {
                        return null;
                    }

                    switch ($expense->getBillableMode()) {
                        case Timesheet::BILLABLE_NO:
                            $expense->setRefundable(false);
                            break;
                        case Timesheet::BILLABLE_YES:
                            $expense->setRefundable(true);
                            break;
                        case Timesheet::BILLABLE_AUTOMATIC:
                            $billable = true;

                            $activity = $expense->getActivity();
                            if ($activity !== null && !$activity->isBillable()) {
                                $billable = false;
                            }

                            $project = $expense->getProject();
                            if ($billable && $project !== null && !$project->isBillable()) {
                                $billable = false;
                            }

                            if ($billable && $project !== null) {
                                $customer = $project->getCustomer();
                                if ($customer !== null && !$customer->isBillable()) {
                                    $billable = false;
                                }
                            }

                            $expense->setRefundable($billable);
                            break;
                    }

                    // calculate cost from category IF cost is empty
                    // or the user is not allowed to edit the cost
                    if (null === $expense->getCost() || !$options['include_cost']) {
                        $cost = 0.00;
                        if ($expense->getExpenseCategory()->getCost() !== null) {
                            $cost = $expense->getExpenseCategory()->getCost();
                        }
                        $expense->setCost($cost);
                    }

                    return $expense;
                }
            )
        );
    }

    /**
     * This method exists for the API
     *
     * @param array<string, array<mixed>|int|bool|string|float> $options
     */
    protected function addBegin(FormBuilderInterface $builder, array $options): void
    {
        $type = DateTimePickerType::class;
        if ($this->systemConfiguration->find('expenses.exclude_time') === '1') {
            $type = DatePickerType::class;
        }
        $builder->add('begin', $type, array_merge($options, ['force_time' => Expense::DEFAULT_TIME]));
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Expense::class,
            'csrf_protection' => true,
            'csrf_field_name' => '_token',
            'csrf_token_id' => 'expense_edit',
            'include_exported' => true, // true by default for API
            'include_cost' => true, // true by default for API
            'include_user' => true, // true by default for API
            'currency' => null,
            'method' => Request::METHOD_POST,
            'timezone' => date_default_timezone_get(),
            'attr' => [
                'data-form-event' => 'kimai.expenseUpdate',
                'data-msg-success' => 'action.update.success',
                'data-msg-error' => 'action.update.error',
            ],
        ]);
    }
}
