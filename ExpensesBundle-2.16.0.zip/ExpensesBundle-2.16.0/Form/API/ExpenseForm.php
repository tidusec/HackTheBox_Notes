<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Form\API;

use App\Form\API\DateTimeApiType;
use KimaiPlugin\ExpensesBundle\Form\ExpenseForm as BaseExpenseForm;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ExpenseForm extends BaseExpenseForm
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        parent::buildForm($builder, $options);

        if ($builder->has('metaFields')) {
            $builder->remove('metaFields');
        }

        if ($builder->has('customer')) {
            $builder->remove('customer');
        }
    }

    /**
     * This method exists for the API
     *
     * @param array<string, array<mixed>|int|bool|string|float> $options
     */
    protected function addBegin(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('begin', DateTimeApiType::class, $options);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        parent::configureOptions($resolver);

        $resolver->setDefaults([
            'csrf_protection' => false,
        ]);
    }
}
