<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Controller;

use App\Controller\AbstractController;
use App\Entity\Activity;
use App\Entity\Customer;
use App\Entity\Project;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesCategoryRepository;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route(path: '/expenses')]
#[IsGranted('view_expense')]
final class DetailController extends AbstractController
{
    public function __construct(private readonly ExpensesCategoryRepository $repository)
    {
    }

    public function customer(Customer $customer): Response
    {
        $createUrl = null;
        if ($this->isGranted('create_expense')) {
            $createUrl = $this->generateUrl('expenses_create');
        }

        return $this->render('@Expenses/entity-details-task.html.twig', [
            'statistics' => $this->repository->getCustomerStatistic($customer),
            'entity' => $customer,
            'currency' => $customer->getCurrency(),
            'create_url' => $createUrl,
            'filter_url' => $this->generateUrl('expenses', ['customers[]' => $customer->getId(), 'performSearch' => 'all']),
        ]);
    }

    public function project(Project $project): Response
    {
        $createUrl = null;
        if ($this->isGranted('create_expense')) {
            $createUrl = $this->generateUrl('expenses_from_project', ['project' => $project->getId()]);
        }

        return $this->render('@Expenses/entity-details-task.html.twig', [
            'statistics' => $this->repository->getProjectStatistic($project),
            'entity' => $project,
            'currency' => $project->getCustomer()->getCurrency(),
            'create_url' => $createUrl,
            'filter_url' => $this->generateUrl('expenses', ['projects[]' => $project->getId(), 'performSearch' => 'all']),
        ]);
    }

    public function activity(Activity $activity): Response
    {
        $createUrl = null;
        if ($this->isGranted('create_expense')) {
            $createUrl = $this->generateUrl('expenses_from_activity', ['activity' => $activity->getId()]);
        }

        return $this->render('@Expenses/entity-details-task.html.twig', [
            'statistics' => $this->repository->getActivityStatistic($activity),
            'entity' => $activity,
            'currency' => $activity->isGlobal() ? null : $activity->getProject()->getCustomer()->getCurrency(),
            'create_url' => $createUrl,
            'filter_url' => $this->generateUrl('expenses', ['activities[]' => $activity->getId(), 'performSearch' => 'all']),
        ]);
    }
}
