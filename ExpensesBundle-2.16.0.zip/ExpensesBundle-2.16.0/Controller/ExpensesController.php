<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Controller;

use App\Controller\AbstractController;
use App\Entity\Activity;
use App\Entity\MetaTableTypeInterface;
use App\Entity\Project;
use App\Entity\Timesheet;
use App\Export\Spreadsheet\EntityWithMetaFieldsExporter;
use App\Export\Spreadsheet\Writer\BinaryFileResponseWriter;
use App\Export\Spreadsheet\Writer\XlsxWriter;
use App\Form\MultiUpdate\MultiUpdateTable;
use App\Form\MultiUpdate\MultiUpdateTableDTO;
use App\Repository\Query\TimesheetQuery;
use App\Utils\DataTable;
use App\Utils\PageSetup;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use KimaiPlugin\ExpensesBundle\Event\ExpenseMetaDefinitionEvent;
use KimaiPlugin\ExpensesBundle\Event\ExpenseMetaDisplayEvent;
use KimaiPlugin\ExpensesBundle\Export\ExpenseExportService;
use KimaiPlugin\ExpensesBundle\Form\ExpenseForm;
use KimaiPlugin\ExpensesBundle\Form\ExpensePreCreateForm;
use KimaiPlugin\ExpensesBundle\Form\ExpenseToolbarForm;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesCategoryRepository;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesRepository;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Contracts\Translation\TranslatorInterface;

#[Route(path: '/expenses')]
#[IsGranted('view_expense')]
final class ExpensesController extends AbstractController
{
    public function __construct(
        private readonly ExpensesRepository $repository,
        private readonly ExpenseExportService $exportService,
        private readonly EventDispatcherInterface $dispatcher
    )
    {
    }

    private function getDefaultQuery(): ExpenseQuery
    {
        $query = new ExpenseQuery();
        $query->setCurrentUser($this->getUser());
        if (!$this->isGranted('view_other_timesheet')) {
            $query->setUser($this->getUser());
        }

        return $query;
    }

    /**
     * @param ExpenseQuery $query
     * @return MetaTableTypeInterface[]
     */
    private function findMetaColumns(ExpenseQuery $query): array
    {
        $event = new ExpenseMetaDisplayEvent($query, ExpenseMetaDisplayEvent::EXPENSE);
        $this->dispatcher->dispatch($event);

        return $event->getFields();
    }

    #[Route(path: '/{page}', defaults: ['page' => 1], requirements: ['page' => '[1-9]\d*'], name: 'expenses', methods: ['GET'])]
    public function index(int $page, Request $request, ExpensesCategoryRepository $categories, TranslatorInterface $translator): Response
    {
        if (!$categories->hasVisibleCategory()) {
            $category = new ExpenseCategory($translator->trans('default'));
            $categories->saveCategory($category);
        }

        $query = $this->getDefaultQuery();
        $query->setPage($page);

        $form = $this->getToolbarForm($query);
        if ($this->handleSearch($form, $request)) {
            return $this->redirectToRoute('expenses');
        }

        $result = $this->repository->getExpenseResult($query);
        $metaColumns = $this->findMetaColumns($query);

        $table = new DataTable('expenses', $query);
        $table->setPagination($result->getPagerfanta());
        $table->setSearchForm($form);
        $table->setPaginationRoute('expenses');
        $table->setReloadEvents('kimai.expenseUpdate');
        if ($this->isGranted('delete_expense')) {
            $table->setBatchForm($this->getMultiUpdateActionForm());
        }

        $table->addColumn('avatar', ['class' => 'd-none d-sm-table-cell text-nowrap w-avatar', 'title' => false, 'orderBy' => false]);
        $table->addColumn('date', ['class' => 'd-none d-sm-table-cell text-nowrap w-min', 'orderBy' => 'begin']);
        $table->addColumn('customer', ['class' => 'alwaysVisible']);
        $table->addColumn('expense_total', ['class' => 'text-nowrap w-min text-end', 'orderBy' => 'total', 'title' => 'sum.total']);
        $table->addColumn('category', ['class' => 'd-none d-md-table-cell text-nowrap w-min', 'orderBy' => 'category']);
        $table->addColumn('project', ['class' => 'd-none']);
        $table->addColumn('description', ['class' => 'd-none']);
        $table->addColumn('user', ['class' => 'd-none']);

        foreach ($metaColumns as $metaColumn) {
            $table->addColumn('mf_' . $metaColumn->getName(), ['title' => $metaColumn->getLabel(), 'class' => 'd-none', 'orderBy' => false]);
        }

        $table->addColumn('refundable', ['class' => 'd-none d-lg-table-cell text-center w-min', 'title' => 'billable']);
        $table->addColumn('exported', ['class' => 'd-none text-center w-min']);
        $table->addColumn('actions', ['class' => 'actions alwaysVisible']);

        $page = new PageSetup('Expenses');
        $page->setActionName('expenses');
        $page->setHelp('plugin-expenses.html');
        $page->setDataTable($table);

        return $this->render('@Expenses/index.html.twig', [
            'page_setup' => $page,
            'dataTable' => $table,
            'metaColumns' => $metaColumns,
            'stats' => $result->getStatistic(),
        ]);
    }

    #[Route(path: '/{id}/edit', name: 'expenses_edit', methods: ['GET', 'POST'])]
    #[IsGranted('edit_expense', 'expense')]
    public function editAction(Expense $expense, Request $request): Response
    {
        return $this->renderEditForm($expense, $request);
    }

    #[Route(path: '/create', name: 'expenses_create', methods: ['GET', 'POST'])]
    #[IsGranted('create_expense')]
    public function createAction(Request $request): Response
    {
        $user = $this->getUser();

        $expense = new Expense();
        $expense->setUser($user);
        // TODO can be shortened, for now and as BC level, we use the long format
        //$expense->setBegin($this->getDateTimeFactory($user)->createDate());
        $expense->setBegin(\DateTimeImmutable::createFromInterface($this->getDateTimeFactory($user)->createDateTime(Expense::DEFAULT_TIME)));

        $event = new ExpenseMetaDefinitionEvent($expense);
        $this->dispatcher->dispatch($event);

        $preForm = $this->createFormForGetRequest(ExpensePreCreateForm::class, $expense, [
            'include_user' => $this->isGranted('view_other_timesheet'),
            'timezone' => $this->getDateTimeFactory()->getTimezone()->getName(),
        ]);
        $preForm->submit($request->query->all(), false);

        return $this->renderEditForm($expense, $request, false);
    }

    #[Route(path: '/{id}/duplicate', name: 'expenses_duplicate', methods: ['GET', 'POST'])]
    #[IsGranted('create_expense')]
    #[IsGranted('edit_expense', 'expense')]
    public function duplicateAction(Expense $expense, Request $request): Response
    {
        $expense = clone $expense;

        return $this->renderEditForm($expense, $request);
    }

    /**
     * @param Request $request
     * @param string $exporterId
     * @return Response
     */
    #[Route(path: '/export/{exporterId}', name: 'expenses_export', methods: ['GET'])]
    #[IsGranted('export_expense')]
    public function exportAction(Request $request, string $exporterId)
    {
        $query = $this->getDefaultQuery();

        $form = $this->getToolbarForm($query);
        $form->setData($query);
        $form->submit($request->query->all(), false);

        $exporter = $this->exportService->getExporterById($exporterId);

        if (null === $exporter) {
            throw $this->createNotFoundException('Invalid expense exporter given');
        }

        $entries = $this->repository->getExpenseResult($query)->getResults();

        /** @var TimesheetQuery $timesheetQuery */
        $timesheetQuery = $query->copyTo(new TimesheetQuery());
        $timesheetQuery->setCustomers($query->getCustomers());
        $timesheetQuery->setProjects($query->getProjects());
        $timesheetQuery->setActivities($query->getActivities());
        $timesheetQuery->setDateRange($query->getDateRange());
        $timesheetQuery->setUser($query->getUser());
        $timesheetQuery->setTeams($query->getTeams());

        return $exporter->render($entries, $timesheetQuery);
    }

    #[Route(path: '/export', name: 'expenses_export_new', methods: ['GET'])]
    public function exportNewAction(Request $request, EntityWithMetaFieldsExporter $exporter): Response
    {
        $query = $this->getDefaultQuery();

        $form = $this->getToolbarForm($query);
        $form->setData($query);
        $form->submit($request->query->all(), false);

        if (!$form->isValid()) {
            $query->resetByFormError($form->getErrors());
        }

        $entries = $this->repository->getExpenseResult($query)->getResults();

        $spreadsheet = $exporter->export(
            Expense::class,
            $entries,
            new ExpenseMetaDisplayEvent($query, ExpenseMetaDisplayEvent::EXPORT)
        );
        $writer = new BinaryFileResponseWriter(new XlsxWriter(), 'kimai-expenses');

        return $writer->getFileResponse($spreadsheet);
    }

    #[Route(path: '/{id}/from_timesheet', name: 'expenses_from_timesheet', methods: ['GET', 'POST'])]
    #[IsGranted('create_expense')]
    public function fromTimesheet(Timesheet $timesheet, Request $request): Response
    {
        $expense = new Expense();
        $expense->setProject($timesheet->getProject());
        $expense->setActivity($timesheet->getActivity());
        $expense->setBegin(\DateTimeImmutable::createFromInterface($timesheet->getBegin()));
        $expense->setUser($timesheet->getUser());

        return $this->renderEditForm($expense, $request);
    }

    #[Route(path: '/{project}/from_project', name: 'expenses_from_project', methods: ['GET'])]
    #[IsGranted('create_expense')]
    public function fromProject(Project $project, Request $request): Response
    {
        $expense = new Expense();
        $expense->setProject($project);
        $expense->setUser($this->getUser());

        return $this->renderEditForm($expense, $request);
    }

    #[Route(path: '/{activity}/from_activity', name: 'expenses_from_activity', methods: ['GET'])]
    #[IsGranted('create_expense')]
    public function fromActivity(Activity $activity, Request $request): Response
    {
        $expense = new Expense();
        $expense->setActivity($activity);
        $expense->setUser($this->getUser());

        if (!$activity->isGlobal()) {
            $expense->setProject($activity->getProject());
        }

        return $this->renderEditForm($expense, $request);
    }

    #[Route(path: '/{id}/delete', name: 'expenses_delete', methods: ['GET', 'POST'])]
    #[IsGranted('delete_expense', 'expense')]
    public function deleteAction(Expense $expense, Request $request): Response
    {
        $deleteForm = $this->createFormBuilder(null, [
                'attr' => [
                    'data-form-event' => 'kimai.expenseUpdate'
                ],
            ])
            ->setAction($this->generateUrl('expenses_delete', ['id' => $expense->getId()]))
            ->setMethod('POST')
            ->getForm();

        $deleteForm->handleRequest($request);

        if ($deleteForm->isSubmitted() && $deleteForm->isValid()) {
            try {
                $this->repository->deleteExpense($expense);
                $this->flashSuccess('action.delete.success');
            } catch (\Exception $ex) {
                $this->flashDeleteException($ex);
            }

            return $this->redirectToRoute('expenses');
        }

        $page = new PageSetup('Expenses');
        $page->setHelp('plugin-expenses.html');

        return $this->render('@Expenses/delete.html.twig', [
            'page_setup' => $page,
            'expense' => $expense,
            'form' => $deleteForm->createView(),
        ]);
    }

    private function getToolbarForm(ExpenseQuery $query): FormInterface
    {
        return $this->createSearchForm(ExpenseToolbarForm::class, $query, [
            'action' => $this->generateUrl('expenses', [
                'page' => $query->getPage(),
            ]),
            'timezone' => $this->getDateTimeFactory()->getTimezone()->getName(),
            'include_user' => $this->isGranted('view_other_timesheet'),
        ]);
    }

    private function renderEditForm(Expense $expense, Request $request, bool $withMeta = true): Response
    {
        if ($withMeta) {
            $event = new ExpenseMetaDefinitionEvent($expense);
            $this->dispatcher->dispatch($event);
        }

        $editForm = $this->createEditForm($expense);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            try {
                $this->repository->saveExpense($expense);
                $this->flashSuccess('action.update.success');

                return $this->redirectToRoute('expenses');
            } catch (\Exception $ex) {
                $this->flashUpdateException($ex);
            }
        }

        $page = new PageSetup('Expenses');
        $page->setHelp('plugin-expenses.html');

        return $this->render('@Expenses/edit.html.twig', [
            'page_setup' => $page,
            'expense' => $expense,
            'form' => $editForm->createView(),
        ]);
    }

    private function createEditForm(Expense $entity): FormInterface
    {
        if (null === $entity->getId()) {
            $url = $this->generateUrl('expenses_create');
        } else {
            $url = $this->generateUrl('expenses_edit', ['id' => $entity->getId()]);
        }

        return $this->createForm(ExpenseForm::class, $entity, [
            'action' => $url,
            'include_exported' => $this->isGranted('edit_exported_expense'),
            'include_cost' => $this->isGranted('edit_expense_cost'),
            'include_user' => $this->isGranted('view_other_timesheet'),
            'timezone' => $this->getDateTimeFactory()->getTimezone()->getName(),
        ]);
    }

    private function getMultiUpdateActionForm(): FormInterface
    {
        $dto = new MultiUpdateTableDTO();

        $dto->addDelete($this->generateUrl('expense_multi_delete'));

        return $this->createForm(MultiUpdateTable::class, $dto, [
            'action' => $this->generateUrl('expenses'),
            'repository' => $this->repository,
            'method' => 'POST',
        ]);
    }

    #[Route(path: '/multi-delete', name: 'expense_multi_delete', methods: ['POST'])]
    #[IsGranted('delete_own_timesheet')]
    public function multiDeleteAction(Request $request): Response
    {
        $form = $this->getMultiUpdateActionForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $dto = $form->getData();
            $entities = [];
            /** @var Expense $entity */
            foreach ($dto->getEntities() as $entity) {
                if (!$this->isGranted('delete_expense', $entity)) {
                    continue;
                }
                $entities[] = $entity;
            }

            try {
                $this->repository->deleteMultiple($entities);
                $this->flashSuccess('action.delete.success');
            } catch (\Exception $ex) {
                $this->flashDeleteException($ex);
            }
        }

        return $this->redirectToRoute('expenses');
    }
}
