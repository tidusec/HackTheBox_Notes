<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Controller;

use App\Controller\AbstractController;
use App\Utils\DataTable;
use App\Utils\PageSetup;
use Doctrine\DBAL\ParameterType;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use KimaiPlugin\ExpensesBundle\Form\ExpenseCategoryForm;
use KimaiPlugin\ExpensesBundle\Form\Type\ExpenseCategoryType;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesCategoryRepository;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Symfony\Contracts\Translation\TranslatorInterface;

#[Route(path: '/expenses/categories')]
#[IsGranted('view_expense')]
#[IsGranted('manage_expense_category')]
final class ExpenseCategoriesController extends AbstractController
{
    public function __construct(private ExpensesCategoryRepository $repository)
    {
    }

    #[Route(path: '/{page}', defaults: ['page' => 1], requirements: ['page' => '[1-9]\d*'], name: 'expense_categories', methods: ['GET'])]
    public function index(int $page, TranslatorInterface $translator): Response
    {
        if (!$this->repository->hasVisibleCategory()) {
            $default = $translator->trans('default');
            $result = $this->repository->findOneBy(['name' => $default]);
            if ($result === null) {
                $category = new ExpenseCategory($default);
                $this->repository->saveCategory($category);
            }
        }

        $query = new ExpenseQuery();
        $query->setCurrentUser($this->getUser());
        $query->setPage($page);

        $entries = $this->repository->getPagerfantaForQuery($query);

        $table = new DataTable('expense_categories', $query);
        $table->setPagination($entries);
        $table->setPaginationRoute('expense_categories');
        $table->setReloadEvents('kimai.expenseCategoryUpdate');

        $table->addColumn('name', ['class' => 'text-nowrap alwaysVisible', 'orderBy' => false]);
        $table->addColumn('help', ['title' => 'help', 'class' => 'd-none d-xl-table-cell', 'orderBy' => false]);
        $table->addColumn('description', ['class' => 'd-none d-md-table-cell', 'orderBy' => false]);
        $table->addColumn('cost', ['title' => 'expense', 'class' => 'text-nowrap text-center w-min', 'orderBy' => false]);
        $table->addColumn('visible', ['class' => 'd-none d-sm-table-cell text-center w-min', 'orderBy' => false]);
        $table->addColumn('actions', ['class' => 'actions alwaysVisible']);

        $page = new PageSetup('Categories');
        $page->setActionName('expense_categories');
        $page->setHelp('plugin-expenses.html');
        $page->setDataTable($table);

        return $this->render('@Expenses/categories/index.html.twig', [
            'page_setup' => $page,
            'dataTable' => $table,
        ]);
    }

    #[Route(path: '/{id}/edit', name: 'expense_categories_edit', methods: ['GET', 'POST'])]
    public function edit(ExpenseCategory $category, Request $request): Response
    {
        return $this->renderEditForm($category, $request);
    }

    #[Route(path: '/create', name: 'expense_categories_create', methods: ['GET', 'POST'])]
    public function create(Request $request): Response
    {
        $category = new ExpenseCategory();

        return $this->renderEditForm($category, $request);
    }

    #[Route(path: '/{id}/delete', name: 'expense_categories_delete', methods: ['GET', 'POST'])]
    public function deleteAction(ExpenseCategory $category, Request $request): Response
    {
        $counter = $this->repository->countUsage($category);

        $deleteForm = $this->createFormBuilder(null, [
                'attr' => [
                    'data-form-event' => 'kimai.expenseCategoryUpdate',
                    'data-msg-success' => 'action.delete.success',
                    'data-msg-error' => 'action.delete.error',
                ],
            ])
            ->add('category', ExpenseCategoryType::class, [
                'query_builder' => function (ExpensesCategoryRepository $repo) use ($category) {
                    $qb = $repo->createQueryBuilder('c');
                    $qb
                        ->andWhere($qb->expr()->eq('c.visible', ':visible'))
                        ->andWhere($qb->expr()->neq('c', ':category'))
                        ->setParameter('visible', true, ParameterType::BOOLEAN)
                        ->setParameter('category', $category)
                    ;

                    return $qb;
                },
                'required' => false,
            ])

            ->setAction($this->generateUrl('expense_categories_delete', ['id' => $category->getId()]))
            ->setMethod('POST')
            ->getForm();

        $deleteForm->handleRequest($request);

        if ($deleteForm->isSubmitted() && $deleteForm->isValid()) {
            try {
                $this->repository->deleteCategory($category, $deleteForm->get('category')->getData());
                $this->flashSuccess('action.delete.success');
            } catch (\Exception $ex) {
                $this->flashDeleteException($ex);
            }

            return $this->redirectToRoute('expense_categories');
        }

        $page = new PageSetup('Categories');
        $page->setHelp('plugin-expenses.html');

        return $this->render('@Expenses/categories/delete.html.twig', [
            'page_setup' => $page,
            'category' => $category,
            'form' => $deleteForm->createView(),
            'counter' => $counter,
        ]);
    }

    private function renderEditForm(ExpenseCategory $category, Request $request): Response
    {
        $editForm = $this->createEditForm($category);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            try {
                $this->repository->saveCategory($category);
                $this->flashSuccess('action.update.success');

                return $this->redirectToRoute('expense_categories');
            } catch (\Exception $ex) {
                $this->flashUpdateException($ex);
            }
        }

        $page = new PageSetup('Categories');
        $page->setHelp('plugin-expenses.html');

        return $this->render('@Expenses/categories/edit.html.twig', [
            'page_setup' => $page,
            'category' => $category,
            'form' => $editForm->createView(),
        ]);
    }

    private function createEditForm(ExpenseCategory $category): FormInterface
    {
        if (null === $category->getId()) {
            $url = $this->generateUrl('expense_categories_create');
        } else {
            $url = $this->generateUrl('expense_categories_edit', ['id' => $category->getId()]);
        }

        return $this->createForm(ExpenseCategoryForm::class, $category, [
            'action' => $url,
        ]);
    }
}
