<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\DependencyInjection;

use App\Plugin\AbstractPluginExtension;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use KimaiPlugin\ExpensesBundle\Form\API\ExpenseForm;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\PrependExtensionInterface;
use Symfony\Component\DependencyInjection\Loader;

final class ExpensesExtension extends AbstractPluginExtension implements PrependExtensionInterface
{
    public function load(array $configs, ContainerBuilder $container): void
    {
        if ('test' === $container->getParameter('kernel.environment')) {
            return;
        }

        // not using a configuration class, because this does not need to be configurable via local.yaml
        $this->registerBundleConfiguration($container, [
            'include_budget' => false
        ]);

        $loader = new Loader\YamlFileLoader($container, new FileLocator(__DIR__ . '/../Resources/config'));
        $loader->load('services.yaml');
    }

    public function prepend(ContainerBuilder $container): void
    {
        $container->prependExtensionConfig('nelmio_api_doc', [
            'models' => [
                'names' => [
                    [
                        'alias' => 'ExpenseEditForm',
                        'type' => ExpenseForm::class,
                        'groups' => ['Default', 'Entity', 'Expense'],
                    ],
                    [
                        'alias' => 'ExpenseEntity',
                        'type' => Expense::class,
                        'groups' => ['Default', 'Entity', 'Expense', 'Expense_Entity'],
                    ],
                    [
                        'alias' => 'ExpenseCategory',
                        'type' => ExpenseCategory::class,
                        'groups' => ['Default', 'Entity', 'ExpenseCategory'],
                    ],
                ],
            ]
        ]);

        $container->prependExtensionConfig('kimai', [
            'permissions' => [
                'roles' => [
                    'ROLE_USER' => [
                        'view_expense',
                        'edit_expense',
                        'create_expense',
                        'export_expense',
                        'delete_expense',
                    ],
                    'ROLE_TEAMLEAD' => [
                        'view_expense',
                        'edit_expense',
                        'create_expense',
                        'export_expense',
                        'delete_expense',
                    ],
                    'ROLE_ADMIN' => [
                        'view_expense',
                        'edit_expense',
                        'edit_exported_expense',
                        'edit_expense_cost',
                        'create_expense',
                        'export_expense',
                        'delete_expense',
                        'manage_expense_category'
                    ],
                    'ROLE_SUPER_ADMIN' => [
                        'view_expense',
                        'edit_expense',
                        'edit_exported_expense',
                        'edit_expense_cost',
                        'create_expense',
                        'export_expense',
                        'delete_expense',
                        'manage_expense_category'
                    ],
                ],
            ],
        ]);

        $container->prependExtensionConfig('jms_serializer', [
            'metadata' => [
                'warmup' => [
                    'paths' => [
                        'included' => [
                            __DIR__ . '/../Entity/'
                        ],
                    ],
                ],
            ],
        ]);
    }
}
