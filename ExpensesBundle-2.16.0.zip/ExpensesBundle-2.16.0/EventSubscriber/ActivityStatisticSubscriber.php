<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\ActivityBudgetStatisticEvent;
use App\Event\ActivityStatisticEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ActivityStatisticSubscriber extends AbstractStatisticSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            ActivityStatisticEvent::class => ['onEvent', 100],
            ActivityBudgetStatisticEvent::class => ['onBudgetEvent', 100],
        ];
    }

    public function onEvent(ActivityStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $stats = $event->getStatistic();
        $begin = $event->getBegin();
        $end = $event->getEnd();

        $expenseStatistic = $this->repository->getActivityStatistic($event->getActivity(), $begin, $end);

        $stats->setRate($stats->getRate() + $expenseStatistic['rate']);
        $stats->setRateExported($stats->getRateExported() + $expenseStatistic['rate_exported']);
        $stats->setRateBillable($stats->getRateBillable() + $expenseStatistic['refundable']);
        $stats->setRateBillableExported($stats->getRateBillableExported() + $expenseStatistic['refundable_exported']);
    }

    public function onBudgetEvent(ActivityBudgetStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $models = $event->getModels();

        $activities = [];
        foreach ($models as $model) {
            $activities[] = $model->getActivity();
        }

        $expenseStatistics = $this->repository->getActivityStatistics($activities, null, $event->getEnd());
        foreach ($expenseStatistics as $id => $expenseStatistic) {
            $model = $event->getModel($id);
            if ($model === null) {
                continue;
            }
            $stat = $model->getStatisticTotal();
            $stat->setRate($stat->getRate() + $expenseStatistic['rate']);
            $stat->setRateExported($stat->getRateExported() + $expenseStatistic['rate_exported']);
            $stat->setRateBillable($stat->getRateBillable() + $expenseStatistic['refundable']);
            $stat->setRateBillableExported($stat->getRateBillableExported() + $expenseStatistic['refundable_exported']);
        }

        $expenseStatistics = $this->repository->getActivityStatistics($activities, $event->getBegin(), $event->getEnd());
        foreach ($expenseStatistics as $id => $expenseStatistic) {
            $model = $event->getModel($id);
            if ($model === null) {
                continue;
            }
            $stat = $model->getStatistic();
            $stat->setRate($stat->getRate() + $expenseStatistic['rate']);
            $stat->setRateExported($stat->getRateExported() + $expenseStatistic['rate_exported']);
            $stat->setRateBillable($stat->getRateBillable() + $expenseStatistic['refundable']);
            $stat->setRateBillableExported($stat->getRateBillableExported() + $expenseStatistic['refundable_exported']);
        }
    }
}
