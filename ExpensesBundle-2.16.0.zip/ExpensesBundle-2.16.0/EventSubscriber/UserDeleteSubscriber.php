<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\UserDeletePreEvent;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesRepository;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class UserDeleteSubscriber implements EventSubscriberInterface
{
    public function __construct(private ExpensesRepository $expensesRepository)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            UserDeletePreEvent::class => ['onUserDelete', 100],
        ];
    }

    public function onUserDelete(UserDeletePreEvent $event): void
    {
        $this->expensesRepository->deleteUser($event->getUser(), $event->getReplacementUser());
    }
}
