<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Configuration\SystemConfiguration;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesRepository;

abstract class AbstractStatisticSubscriber
{
    /**
     * @var ExpensesRepository
     */
    protected $repository;
    private $systemConfiguration;
    /**
     * @var bool
     */
    private $enabled;

    public function __construct(ExpensesRepository $repository, SystemConfiguration $systemConfiguration)
    {
        $this->repository = $repository;
        $this->systemConfiguration = $systemConfiguration;
    }

    protected function isActivated(): bool
    {
        if ($this->enabled === null) {
            $result = $this->systemConfiguration->find('expenses.include_budget');

            if ($result === null) {
                $result = false;
            }

            $this->enabled = (bool) $result;
        }

        return $this->enabled;
    }
}
