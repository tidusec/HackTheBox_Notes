<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\PageActionsEvent;
use App\EventSubscriber\Actions\AbstractActionsSubscriber;
use KimaiPlugin\ExpensesBundle\Export\ExpenseExportService;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

class ExpensesSubscriber extends AbstractActionsSubscriber
{
    public function __construct(AuthorizationCheckerInterface $security, UrlGeneratorInterface $urlGenerator, private ExpenseExportService $expenseExportService)
    {
        parent::__construct($security, $urlGenerator);
    }

    public static function getActionName(): string
    {
        return 'expenses';
    }

    public function onActions(PageActionsEvent $event): void
    {
        if ($this->isGranted('create_expense')) {
            $event->addCreate($this->path('expenses_create'));
        }

        if ($this->isGranted('export_expense')) {
            $event->addAction('download', ['title' => 'export']);
            $event->addActionToSubmenu('download', 'xlsx1', ['title' => 'button.xlsx', 'url' => $this->path('expenses_export_new'), 'class' => 'toolbar-action', 'data-target' => '_blank']);
            foreach ($this->expenseExportService->getExporter() as $exporter) {
                $id = $exporter->getId();
                $event->addActionToSubmenu('download', 'exporter' . $id, ['title' => 'button.' . $id, 'url' => $this->path('expenses_export', ['exporterId' => $id]), 'class' => 'toolbar-action exporter-' . $id, 'attr' => ['data-target' => '_blank']]);
            }
        }
    }
}
