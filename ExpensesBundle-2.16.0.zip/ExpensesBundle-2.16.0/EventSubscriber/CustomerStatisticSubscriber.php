<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\CustomerStatisticEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class CustomerStatisticSubscriber extends AbstractStatisticSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            CustomerStatisticEvent::class => ['onEvent', 100],
        ];
    }

    public function onEvent(CustomerStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $stats = $event->getStatistic();
        $begin = $event->getBegin();
        $end = $event->getEnd();

        $expenseStatistic = $this->repository->getCustomerStatistic($event->getCustomer(), $begin, $end);

        $stats->setRate($stats->getRate() + $expenseStatistic['rate']);
        $stats->setRateExported($stats->getRateExported() + $expenseStatistic['rate_exported']);
        $stats->setRateBillable($stats->getRateBillable() + $expenseStatistic['refundable']);
        $stats->setRateBillableExported($stats->getRateBillableExported() + $expenseStatistic['refundable_exported']);
    }
}
