<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\RevenueStatisticEvent;
use App\Event\UserRevenueStatisticEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class RevenueStatisticSubscriber extends AbstractStatisticSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            RevenueStatisticEvent::class => ['onEvent', 100],
            UserRevenueStatisticEvent::class => ['onUserEvent', 100],
        ];
    }

    public function onEvent(RevenueStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $expenseStatistic = $this->repository->getStatistics($event->getBegin(), $event->getEnd());
        foreach ($expenseStatistic as $currency => $statistic) {
            $event->addRevenue($currency, $statistic['refundable']);
        }
    }

    public function onUserEvent(UserRevenueStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $expenseStatistic = $this->repository->getStatistics($event->getBegin(), $event->getEnd(), $event->getUser());
        foreach ($expenseStatistic as $currency => $statistic) {
            $event->addRevenue($currency, $statistic['refundable']);
        }
    }
}
