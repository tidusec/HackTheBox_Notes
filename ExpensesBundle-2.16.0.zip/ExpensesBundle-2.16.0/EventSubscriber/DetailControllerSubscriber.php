<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\ActivityDetailControllerEvent;
use App\Event\CustomerDetailControllerEvent;
use App\Event\ProjectDetailControllerEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class DetailControllerSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            CustomerDetailControllerEvent::class => ['onCustomer', 100],
            ProjectDetailControllerEvent::class => ['onProject', 100],
            ActivityDetailControllerEvent::class => ['onActivity', 100],
        ];
    }

    public function onCustomer(CustomerDetailControllerEvent $event): void
    {
        $event->addController('KimaiPlugin\\ExpensesBundle\\Controller\\DetailController::customer');
    }

    public function onProject(ProjectDetailControllerEvent $event): void
    {
        $event->addController('KimaiPlugin\\ExpensesBundle\\Controller\\DetailController::project');
    }

    public function onActivity(ActivityDetailControllerEvent $event): void
    {
        $event->addController('KimaiPlugin\\ExpensesBundle\\Controller\\DetailController::activity');
    }
}
