<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber\Actions;

use App\Entity\Customer;
use App\Event\PageActionsEvent;
use App\EventSubscriber\Actions\AbstractActionsSubscriber;

class CustomerSubscriber extends AbstractActionsSubscriber
{
    public static function getActionName(): string
    {
        return 'customer';
    }

    public function onActions(PageActionsEvent $event): void
    {
        $payload = $event->getPayload();

        if (!isset($payload['customer'])) {
            return;
        }

        /** @var Customer $customer */
        $customer = $payload['customer'];

        // new customers can't be filtered
        if (null === $customer->getId()) {
            return;
        }

        if (!$this->isGranted('view_expense')) {
            return;
        }

        $event->addActionToSubmenu('filter', 'expenses', [
            'title' => 'Expenses',
            'url' => $this->path('expenses', ['customers[]' => $customer->getId()]),
        ]);
    }
}
