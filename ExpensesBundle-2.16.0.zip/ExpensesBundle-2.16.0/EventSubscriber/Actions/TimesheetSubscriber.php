<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber\Actions;

use App\Entity\Timesheet;
use App\Event\PageActionsEvent;
use App\EventSubscriber\Actions\AbstractActionsSubscriber;

class TimesheetSubscriber extends AbstractActionsSubscriber
{
    public static function getActionName(): string
    {
        return 'timesheet';
    }

    public function onActions(PageActionsEvent $event): void
    {
        $payload = $event->getPayload();

        if (!isset($payload['timesheet'])) {
            return;
        }

        /** @var Timesheet $timesheet */
        $timesheet = $payload['timesheet'];

        // new items are not supported
        if (null === $timesheet->getId()) {
            return;
        }

        if (!$this->isGranted('create_expense')) {
            return;
        }

        $event->addAction('expense_create', [
            'icon' => 'fas fa-money-check',
            'url' => $this->path('expenses_from_timesheet', ['id' => $timesheet->getId()]),
            'class' => 'modal-ajax-form',
            'title' => 'expense_create',
        ]);
    }
}
