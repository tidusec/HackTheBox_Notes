<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber\Actions;

use App\Entity\User;
use App\Event\PageActionsEvent;
use App\EventSubscriber\Actions\AbstractActionsSubscriber;

class UserSubscriber extends AbstractActionsSubscriber
{
    public static function getActionName(): string
    {
        return 'user';
    }

    public function onActions(PageActionsEvent $event): void
    {
        $payload = $event->getPayload();

        if (!isset($payload['user'])) {
            return;
        }

        /** @var User $user */
        $user = $payload['user'];

        // new user can't be filtered
        if (null === $user->getId()) {
            return;
        }

        if (!$this->isGranted('view_expense')) {
            return;
        }

        $event->addActionToSubmenu('filter', 'expenses', [
            'title' => 'Expenses',
            'url' => $this->path('expenses', ['users[]' => $user->getId()]),
        ]);
    }
}
