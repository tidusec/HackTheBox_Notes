<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber\Actions;

use App\Entity\Project;
use App\Event\PageActionsEvent;
use App\EventSubscriber\Actions\AbstractActionsSubscriber;

class ProjectSubscriber extends AbstractActionsSubscriber
{
    public static function getActionName(): string
    {
        return 'project';
    }

    public function onActions(PageActionsEvent $event): void
    {
        $payload = $event->getPayload();

        if (!isset($payload['project'])) {
            return;
        }

        /** @var Project $project */
        $project = $payload['project'];

        // new projects can't be filtered
        if (null === $project->getId()) {
            return;
        }

        if (!$this->isGranted('view_expense')) {
            return;
        }

        $event->addActionToSubmenu('filter', 'expenses', [
            'title' => 'Expenses',
            'url' => $this->path('expenses', [
                'customers[]' => $project->getCustomer()->getId(),
                'projects[]' => $project->getId()
            ])
        ]);
    }
}
