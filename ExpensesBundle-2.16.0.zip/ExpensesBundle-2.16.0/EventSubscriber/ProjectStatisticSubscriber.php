<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\ProjectBudgetStatisticEvent;
use App\Event\ProjectStatisticEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class ProjectStatisticSubscriber extends AbstractStatisticSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            ProjectStatisticEvent::class => ['onEvent', 100],
            ProjectBudgetStatisticEvent::class => ['onBudgetEvent', 100],
        ];
    }

    public function onEvent(ProjectStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $stats = $event->getStatistic();
        $begin = $event->getBegin();
        $end = $event->getEnd();

        $expenseStatistic = $this->repository->getProjectStatistic($event->getProject(), $begin, $end);

        $stats->setRate($stats->getRate() + $expenseStatistic['rate']);
        $stats->setRateExported($stats->getRateExported() + $expenseStatistic['rate_exported']);
        $stats->setRateBillable($stats->getRateBillable() + $expenseStatistic['refundable']);
        $stats->setRateBillableExported($stats->getRateBillableExported() + $expenseStatistic['refundable_exported']);
    }

    public function onBudgetEvent(ProjectBudgetStatisticEvent $event): void
    {
        if (!$this->isActivated()) {
            return;
        }

        $models = $event->getModels();

        $projects = [];
        foreach ($models as $model) {
            $projects[] = $model->getProject();
        }

        $expenseStatistics = $this->repository->getProjectStatistics($projects, null, $event->getEnd());
        foreach ($expenseStatistics as $id => $expenseStatistic) {
            $model = $event->getModel($id);
            if ($model === null) {
                continue;
            }
            $stat = $model->getStatisticTotal();
            $stat->setRate($stat->getRate() + $expenseStatistic['rate']);
            $stat->setRateExported($stat->getRateExported() + $expenseStatistic['rate_exported']);
            $stat->setRateBillable($stat->getRateBillable() + $expenseStatistic['refundable']);
            $stat->setRateBillableExported($stat->getRateBillableExported() + $expenseStatistic['refundable_exported']);
        }

        $expenseStatistics = $this->repository->getProjectStatistics($projects, $event->getBegin(), $event->getEnd());
        foreach ($expenseStatistics as $id => $expenseStatistic) {
            $model = $event->getModel($id);
            if ($model === null) {
                continue;
            }
            $stat = $model->getStatistic();
            $stat->setRate($stat->getRate() + $expenseStatistic['rate']);
            $stat->setRateExported($stat->getRateExported() + $expenseStatistic['rate_exported']);
            $stat->setRateBillable($stat->getRateBillable() + $expenseStatistic['refundable']);
            $stat->setRateBillableExported($stat->getRateBillableExported() + $expenseStatistic['refundable_exported']);
        }
    }
}
