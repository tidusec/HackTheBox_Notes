<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\SystemConfigurationEvent;
use App\Form\Model\Configuration;
use App\Form\Model\SystemConfiguration;
use App\Form\Type\YesNoType;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

final class SystemConfigurationSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            SystemConfigurationEvent::class => ['onSystemConfiguration', 100],
        ];
    }

    public function onSystemConfiguration(SystemConfigurationEvent $event): void
    {
        $event->addConfiguration(
            (new SystemConfiguration('Expenses'))
            ->setTranslationDomain('messages')
            ->setConfiguration([
                (new Configuration('expenses.include_budget'))
                    ->setLabel('expenses.include_budget')
                    ->setType(YesNoType::class),
                (new Configuration('expenses.exclude_time'))
                    ->setLabel('expenses.exclude_time')
                    ->setType(YesNoType::class),
            ])
        );
    }
}
