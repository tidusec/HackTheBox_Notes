<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\EventSubscriber;

use App\Event\ConfigureMainMenuEvent;
use App\Utils\MenuItemModel;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Security\Core\Authorization\AuthorizationCheckerInterface;

final class MenuSubscriber implements EventSubscriberInterface
{
    public function __construct(private AuthorizationCheckerInterface $security)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ConfigureMainMenuEvent::class => ['onMenuConfigure', 100],
        ];
    }

    public function onMenuConfigure(ConfigureMainMenuEvent $event): void
    {
        $auth = $this->security;

        if (!$auth->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
            return;
        }

        if (!$auth->isGranted('view_expense')) {
            return;
        }

        $menu = new MenuItemModel('expense-menu', 'Expenses', null, [], 'fas fa-receipt');
        $menu->setChildRoutes(['expenses_create', 'expenses_edit', 'expenses_from_timesheet', 'expenses_delete']);

        $expense = new MenuItemModel('expenses', 'Expenses', 'expenses', [], 'fas fa-receipt');
        $menu->addChild($expense);

        $hasCategory = false;
        if ($this->security->isGranted('manage_expense_category')) {
            $category = new MenuItemModel('expense_categories', 'Categories', 'expense_categories', [], 'list');
            $menu->addChild($category);
            $hasCategory = true;
        }

        if ($hasCategory) {
            $event->getMenu()->addChild($menu);
        } else {
            $event->getMenu()->addChild($expense);
        }
    }
}
