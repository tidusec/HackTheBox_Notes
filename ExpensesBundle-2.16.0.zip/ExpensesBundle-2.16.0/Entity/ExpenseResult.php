<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Entity;

use App\Repository\Paginator\LoaderPaginator;
use App\Utils\Pagination;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\ORM\QueryBuilder;
use KimaiPlugin\ExpensesBundle\Repository\Loader\ExpenseLoader;
use KimaiPlugin\ExpensesBundle\Repository\Query\ExpenseQuery;

final class ExpenseResult
{
    /**
     * @var array<string, array<string, int|float>>|null
     */
    private ?array $statisticCache = null;
    /**
     * @var null|Expense[]
     */
    private ?array $resultCache = null;
    private ?int $results = null;

    /**
     * @internal
     */
    public function __construct(private ExpenseQuery $query, private QueryBuilder $queryBuilder)
    {
    }

    public function getCounter(): int
    {
        if ($this->results === null) {
            $qb = clone $this->queryBuilder;
            $qb
                ->resetDQLPart('select')
                ->resetDQLPart('orderBy')
                ->resetDQLPart('groupBy')
                ->select('COUNT(e.id) as amount');
            $this->results = $qb->getQuery()->getSingleScalarResult();
        }

        return $this->results;
    }

    /**
     * @return array<string, array<string, int|float>>
     */
    public function getStatistic(): array
    {
        if ($this->statisticCache === null) {
            $qb = clone $this->queryBuilder;
            $qb
                ->resetDQLPart('select')
                ->resetDQLPart('orderBy')
                ->resetDQLPart('groupBy')
                ->select('COUNT(e.id) as amount')
                ->addSelect('COALESCE(SUM(e.cost * e.multiplier), 0) as rate')
                ->addSelect('e.refundable as billable')
                ->addSelect('c.currency')
                ->groupBy('c.currency')
                ->addGroupBy('e.refundable')
            ;

            $joinAliases = $qb->getDQLPart('join');
            $foundProject = false;
            $foundCustomer = false;
            /** @var array<Join> $joins */
            foreach ($joinAliases as $joins) {
                foreach ($joins as $join) {
                    if ($join->getAlias() === 'c' && $join->getJoin() === 'p.customer') {
                        $foundCustomer = true;
                    }
                    if ($join->getAlias() === 'p' && $join->getJoin() === 'e.project') {
                        $foundProject = true;
                    }
                }
            }
            if (!$foundProject) {
                $qb->leftJoin('e.project', 'p');
            }
            if (!$foundCustomer) {
                $qb->leftJoin('p.customer', 'c');
            }

            $results = $qb->getQuery()->getArrayResult();
            $statistics = [];

            foreach ($results as $result) {
                $currency = (string) $result['currency'];
                if (!\array_key_exists($currency, $statistics)) {
                    $statistics[$currency] = [
                        'amount' => 0,
                        'rate' => 0.0,
                        'billable' => 0.0,
                    ];
                }
                $statistics[$currency]['amount'] += $result['amount'];
                $statistics[$currency]['rate'] += (float) $result['rate'];
                if ($result['billable']) {
                    $statistics[$currency]['billable'] += (float) $result['rate'];
                }
            }

            $this->statisticCache = $statistics;
        }

        return $this->statisticCache;
    }

    /**
     * @return iterable<Expense>
     */
    public function toIterable(): iterable
    {
        $query = $this->queryBuilder->getQuery();

        return $query->toIterable();
    }

    /**
     * @return array<Expense>
     */
    public function getResults(): array
    {
        if ($this->resultCache === null) {
            $query = $this->queryBuilder->getQuery();
            $results = $query->getResult();

            $loader = new ExpenseLoader($this->queryBuilder->getEntityManager());
            $loader->loadResults($results);

            $this->resultCache = $results;
        }

        return $this->resultCache;
    }

    public function getPagerfanta(): Pagination
    {
        $qb = clone $this->queryBuilder;

        $loader = new LoaderPaginator(new ExpenseLoader($qb->getEntityManager()), $qb, $this->getCounter());

        return new Pagination($loader, $this->query);
    }
}
