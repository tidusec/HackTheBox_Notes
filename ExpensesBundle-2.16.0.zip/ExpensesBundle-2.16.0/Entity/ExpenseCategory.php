<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Entity;

use App\Entity\ColorTrait;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Table(name: 'kimai2_expense_category')]
#[ORM\UniqueConstraint(name: 'expense_category_name', columns: ['name'])]
#[ORM\Entity(repositoryClass: 'KimaiPlugin\ExpensesBundle\Repository\ExpensesCategoryRepository')]
#[UniqueEntity('name')]
#[Serializer\ExclusionPolicy('all')]
class ExpenseCategory
{
    /**
     * Unique category ID
     */
    #[ORM\Column(name: 'id', type: 'integer')]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    private ?int $id = null;
    /**
     * Category name
     */
    #[ORM\Column(name: 'name', type: 'string', length: 100, nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotBlank]
    #[Assert\Length(min: 2, max: 100)]
    private ?string $name = null;
    #[ORM\Column(name: 'help', type: 'string', length: 100, nullable: true)]
    #[Assert\Length(max: 100)]
    private ?string $help = null;
    #[ORM\Column(name: 'visible', type: 'boolean', nullable: false, options: ['default' => true])]
    #[Assert\NotNull]
    private bool $visible = true;
    /**
     * Base cost for expenses of this category
     */
    #[ORM\Column(name: 'cost', type: 'float', precision: 10, scale: 2, nullable: true)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Expense_Category_Entity'])]
    private ?float $cost = null;
    /**
     * Description for new expenses, created from this category
     */
    #[ORM\Column(name: 'description', type: 'text', nullable: true)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Expense_Category_Entity'])]
    private ?string $description = null;

    use ColorTrait;

    public function __construct(?string $name = null)
    {
        $this->setName($name);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): ExpenseCategory
    {
        $this->name = $name;

        return $this;
    }

    public function isVisible(): bool
    {
        return $this->visible;
    }

    public function setVisible(bool $visible): ExpenseCategory
    {
        $this->visible = $visible;

        return $this;
    }

    public function getCost(): ?float
    {
        return $this->cost;
    }

    public function setCost(?float $cost): ExpenseCategory
    {
        $this->cost = $cost;

        return $this;
    }

    public function getHelp(): ?string
    {
        return $this->help;
    }

    public function setHelp(?string $help): ExpenseCategory
    {
        $this->help = $help;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }
}
