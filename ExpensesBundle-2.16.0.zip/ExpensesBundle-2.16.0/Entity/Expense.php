<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Entity;

use App\Entity\Activity;
use App\Entity\EntityWithMetaFields;
use App\Entity\ExportableItem;
use App\Entity\MetaTableTypeInterface;
use App\Entity\Project;
use App\Entity\Timesheet;
use App\Entity\User;
use App\Export\Annotation as Exporter;
use DateTime;
use DateTimeZone;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use KimaiPlugin\ExpensesBundle\Validator\Constraints as Constraints;
use OpenApi\Attributes as OA;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * columns={"user_id"}              => IDX_4F60C6B18D93D649         => user expenses
 * columns={"activity_id"}          => IDX_4F60C6B181C06096         => ???
 * columns={"user_id","start_time"} => IDX_4F60C6B18D93D649502DF587 => user and with date filter
 * columns={"start_time"}           => IDX_4F60C6B1502DF587         => overview with timerange filter only
 */
#[ORM\Table(name: 'kimai2_expense')]
#[ORM\Index(columns: ['user_id'])]
#[ORM\Index(columns: ['activity_id'])]
#[ORM\Index(columns: ['user_id', 'start_time'])]
#[ORM\Index(columns: ['start_time'])]
#[ORM\Entity(repositoryClass: 'KimaiPlugin\ExpensesBundle\Repository\ExpensesRepository')]
#[Exporter\Order(['begin_date', 'begin', 'user', 'username', 'customer', 'project', 'activity', 'multiplier', 'cost', 'expense_total', 'currency', 'exported', 'refundable', 'category', 'description'])]
#[Exporter\Expose(name: 'begin_date', label: 'date', exp: 'object.getBegin()', type: 'date')]
#[Exporter\Expose(name: 'user', label: 'user', exp: 'object.getUser().getDisplayName()')]
#[Exporter\Expose(name: 'expense_total', label: 'sum.total', exp: 'object.getTotal()', type: 'float')]
#[Exporter\Expose(name: 'currency', label: 'currency', exp: 'object.getProject().getCustomer().getCurrency()')]
#[Exporter\Expose(name: 'username', label: 'name', exp: 'object.getUser().getUsername()')]
#[Exporter\Expose(name: 'category', label: 'category', exp: 'object.getCategory()')]
#[Exporter\Expose(name: 'customer', label: 'customer', exp: 'object.getProject().getCustomer().getName()')]
#[Exporter\Expose(name: 'project', label: 'project', exp: 'object.getProject().getName()')]
#[Exporter\Expose(name: 'activity', label: 'activity', exp: 'object.getActivity() === null ? null : object.getActivity().getName()')]
#[Serializer\ExclusionPolicy('all')]
#[Serializer\VirtualProperty('ActivityAsId', exp: 'object.getActivity() === null ? null : object.getActivity().getId()', options: [new Serializer\SerializedName('activity'), new Serializer\Type(name: 'integer'), new Serializer\Groups(['Entity', 'Collection'])])]
#[Serializer\VirtualProperty('ProjectAsId', exp: 'object.getProject() === null ? null : object.getProject().getId()', options: [new Serializer\SerializedName('project'), new Serializer\Type(name: 'integer'), new Serializer\Groups(['Entity', 'Collection'])])]
#[Serializer\VirtualProperty('UserAsId', exp: 'object.getUser().getId()', options: [new Serializer\SerializedName('user'), new Serializer\Type(name: 'integer'), new Serializer\Groups(['Default'])])]
#[Constraints\Expense]
class Expense implements ExportableItem, EntityWithMetaFields
{
    public const DEFAULT_TIME = '12:00:00';

    /**
     * Unique expense ID
     */
    #[ORM\Column(name: 'id', type: 'integer')]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    private ?int $id = null;
    #[ORM\Column(name: 'start_time', type: 'datetime_immutable', nullable: false)]
    #[Exporter\Expose(label: 'begin', type: 'time')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Serializer\Type(name: 'DateTime')]
    #[Serializer\Accessor(getter: 'getBegin')]
    #[Assert\NotNull]
    private ?\DateTimeImmutable $begin = null;
    #[ORM\Column(name: 'timezone', type: 'string', length: 64, nullable: false)]
    private ?string $timezone = null;
    private bool $localized = false;
    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE', nullable: false)]
    #[Assert\NotNull]
    private ?User $user = null;
    #[ORM\ManyToOne(targetEntity: Activity::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE', nullable: true)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Subresource', 'Expanded'])]
    #[OA\Property(ref: '#/components/schemas/ActivityExpanded')]
    private ?Activity $activity = null;
    #[ORM\ManyToOne(targetEntity: Project::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE', nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Subresource', 'Expanded'])]
    #[OA\Property(ref: '#/components/schemas/ProjectExpanded')]
    #[Assert\NotNull]
    private ?Project $project = null;
    #[ORM\ManyToOne(targetEntity: ExpenseCategory::class)]
    #[ORM\JoinColumn(onDelete: 'CASCADE', nullable: false)]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[OA\Property(ref: '#/components/schemas/ExpenseCategory')]
    private ?ExpenseCategory $category = null;
    #[ORM\Column(name: 'description', type: 'text', nullable: true)]
    #[Exporter\Expose(label: 'description', type: 'string')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    private ?string $description = null;
    #[ORM\Column(name: 'cost', type: 'float', precision: 10, scale: 2, nullable: false, options: ['default' => 0])]
    #[Exporter\Expose(label: 'expense', type: 'float')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotNull]
    private ?float $cost = null;
    #[ORM\Column(name: 'multiplier', type: 'float', precision: 10, scale: 2, nullable: false, options: ['default' => 1])]
    #[Exporter\Expose(label: 'amount', type: 'float')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\GreaterThanOrEqual(0)]
    private float $multiplier = 1.00;
    #[ORM\Column(name: 'exported', type: 'boolean', nullable: false, options: ['default' => false])]
    #[Exporter\Expose(label: 'exported', type: 'boolean')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotNull]
    private bool $exported = false;
    #[ORM\Column(name: 'refundable', type: 'boolean', nullable: false, options: ['default' => true])]
    #[Exporter\Expose(label: 'billable', type: 'boolean')]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Assert\NotNull]
    private bool $refundable = true;
    /**
     * Meta fields registered with the expense
     *
     * @var Collection<ExpenseMeta>
     */
    #[ORM\OneToMany(targetEntity: ExpenseMeta::class, mappedBy: 'expense', cascade: ['persist'])]
    #[Serializer\Expose]
    #[Serializer\Groups(['Default'])]
    #[Serializer\Type(name: 'array<KimaiPlugin\ExpensesBundle\Entity\ExpenseMeta>')]
    #[Serializer\SerializedName('metaFields')]
    #[Serializer\Accessor(getter: 'getVisibleMetaFields')]
    private Collection $meta;
    /**
     * Internal property used to determine whether the billable field should be calculated automatically.
     */
    private ?string $billableMode = Timesheet::BILLABLE_DEFAULT;

    public function __construct()
    {
        $this->meta = new ArrayCollection();
    }

    /**
     * Get entry id, returns null for new entities which were not persisted.
     *
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Make sure begin and end date have the correct timezone.
     * This will be called once for each item after being loaded from the database.
     */
    private function localizeDates(): void
    {
        if ($this->localized) {
            return;
        }

        if (null !== $this->begin) {
            $this->begin = $this->begin->setTimeZone(new DateTimeZone($this->timezone));
        }

        $this->localized = true;
    }

    public function getBegin(): ?\DateTime
    {
        $this->localizeDates();

        if ($this->begin === null) {
            return null;
        }

        return DateTime::createFromInterface($this->begin);
    }

    public function setBegin(\DateTimeImmutable $begin): Expense
    {
        $this->begin = $begin;
        $this->timezone = $begin->getTimezone()->getName();

        return $this;
    }

    public function getEnd(): ?DateTime
    {
        if (($begin = $this->getBegin()) === null) {
            return null;
        }

        return DateTime::createFromInterface($begin);
    }

    public function getDuration(): ?int
    {
        return 0;
    }

    public function setUser(?User $user): Expense
    {
        $this->user = $user;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setActivity(?Activity $activity): Expense
    {
        $this->activity = $activity;

        return $this;
    }

    public function getActivity(): ?Activity
    {
        return $this->activity;
    }

    public function setProject(Project $project): Expense
    {
        $this->project = $project;

        return $this;
    }

    public function getProject(): ?Project
    {
        return $this->project;
    }

    #[Assert\NotNull]
    public function getExpenseCategory(): ?ExpenseCategory
    {
        return $this->category;
    }

    public function setExpenseCategory(ExpenseCategory $category): Expense
    {
        $this->category = $category;

        return $this;
    }

    public function setDescription(?string $description): Expense
    {
        $this->description = $description;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * ALLOW PASSING NULL, SO THE FORM TRANSFORMER CAN KICK IN
     * AND CALCULATE THE COST FROM THE CATEGORY
     *
     * @param float|null $cost
     * @return $this
     */
    public function setCost(?float $cost): Expense
    {
        $this->cost = $cost;

        return $this;
    }

    public function getCost(): ?float
    {
        return $this->cost;
    }

    public function setMultiplier(float $multiplier): Expense
    {
        $this->multiplier = (float) $multiplier;

        return $this;
    }

    public function getMultiplier(): float
    {
        return $this->multiplier;
    }

    #[Serializer\VirtualProperty]
    #[Serializer\SerializedName('total')]
    #[Serializer\Type(name: 'float')]
    #[Serializer\Groups(['Default'])]
    public function getTotal(): float
    {
        return $this->multiplier * $this->cost;
    }

    public function isExported(): bool
    {
        return $this->exported;
    }

    public function setExported(bool $exported): Expense
    {
        $this->exported = $exported;

        return $this;
    }

    public function isRefundable(): bool
    {
        return $this->refundable;
    }

    public function isBillable(): bool
    {
        return $this->refundable;
    }

    public function setRefundable(bool $refundable): Expense
    {
        $this->refundable = $refundable;

        return $this;
    }

    public function getBillableMode(): ?string
    {
        return $this->billableMode;
    }

    public function setBillableMode(?string $billableMode): void
    {
        $this->billableMode = $billableMode;
    }

    public function getTimezone(): string
    {
        return $this->timezone;
    }

    /**
     * @internal for invoice only
     */
    public function getFixedRate(): ?float
    {
        return $this->getCost();
    }

    /**
     * @internal for invoice only
     */
    public function getRate(): float
    {
        return $this->getTotal();
    }

    /**
     * @internal for invoice only
     */
    public function getInternalRate(): ?float
    {
        return $this->getTotal();
    }

    /**
     * @internal for invoice only
     */
    public function getHourlyRate(): ?float
    {
        return null;
    }

    public function getAmount(): float
    {
        return $this->getMultiplier();
    }

    public function getCategory(): string
    {
        return $this->category->getName();
    }

    public function getType(): string
    {
        return 'expense';
    }

    /**
     * @internal only here for symfony forms
     * @return Collection<int, ExpenseMeta>
     */
    public function getMetaFields(): Collection
    {
        return $this->meta;
    }

    /**
     * @return ExpenseMeta[]
     */
    public function getVisibleMetaFields(): array
    {
        $all = [];
        foreach ($this->meta as $meta) {
            if ($meta->isVisible()) {
                $all[] = $meta;
            }
        }

        return $all;
    }

    /**
     * @param string $name
     * @return ExpenseMeta|null
     */
    public function getMetaField(string $name): ?MetaTableTypeInterface
    {
        foreach ($this->meta as $field) {
            if (strtolower($field->getName()) === strtolower($name)) {
                return $field;
            }
        }

        return null;
    }

    /**
     * @param ExpenseMeta $meta
     * @return EntityWithMetaFields
     */
    public function setMetaField(MetaTableTypeInterface $meta): EntityWithMetaFields
    {
        if (null === ($current = $this->getMetaField($meta->getName()))) {
            $meta->setEntity($this);
            $this->meta->add($meta);

            return $this;
        }

        $current->merge($meta);

        return $this;
    }

    /**
     * @internal for export only
     * @return string[]
     */
    public function getTagsAsArray(): array
    {
        return [];
    }

    public function __clone()
    {
        if ($this->id) {
            $this->id = null;
        }
        $this->exported = false;

        $fields = $this->meta;
        $this->meta = new ArrayCollection();
        foreach ($fields as $metaField) {
            $metaNew = clone $metaField;
            $this->setMetaField($metaNew);
        }
    }
}
