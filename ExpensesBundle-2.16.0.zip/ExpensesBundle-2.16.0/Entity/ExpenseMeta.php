<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Entity;

use App\Entity\EntityWithMetaFields;
use App\Entity\MetaTableTypeInterface;
use App\Entity\MetaTableTypeTrait;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Table(name: 'kimai2_expense_meta')]
#[ORM\UniqueConstraint(columns: ['expense_id', 'name'])]
#[ORM\Entity]
#[Serializer\ExclusionPolicy('all')]
class ExpenseMeta implements MetaTableTypeInterface
{
    use MetaTableTypeTrait;

    #[ORM\ManyToOne(targetEntity: Expense::class, inversedBy: 'meta')]
    #[ORM\JoinColumn(onDelete: 'CASCADE', nullable: false)]
    #[Assert\NotNull]
    private ?Expense $expense = null;

    public function setEntity(EntityWithMetaFields $entity): MetaTableTypeInterface
    {
        if (!($entity instanceof Expense)) {
            throw new \InvalidArgumentException(
                \sprintf('Expected instanceof Expense, received "%s"', \get_class($entity))
            );
        }
        $this->expense = $entity;

        return $this;
    }

    public function getEntity(): ?EntityWithMetaFields
    {
        return $this->expense;
    }
}
