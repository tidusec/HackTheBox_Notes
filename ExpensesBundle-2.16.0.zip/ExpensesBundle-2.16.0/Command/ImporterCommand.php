<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Command;

use App\Doctrine\DataSubscriberInterface;
use App\Entity\Project;
use App\Entity\User;
use Doctrine\DBAL\Configuration;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DriverManager;
use Doctrine\DBAL\Types\DateTimeType;
use Doctrine\DBAL\Types\Type;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use KimaiPlugin\ExpensesBundle\Entity\ExpenseCategory;
use KimaiPlugin\ExpensesBundle\Validator\Constraints\Expense as ExpenseConstraint;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * Command used to import expense data from a Kimai v1 installation.
 */
#[AsCommand(name: 'kimai:bundle:expenses:import-v1')]
final class ImporterCommand extends Command
{
    // minimum required Kimai and database version, lower versions are not supported by this command
    public const MIN_VERSION = '1.0.1';
    public const MIN_REVISION = '1388';

    /**
     * Connection to the old database to import data from
     */
    private ?Connection $connection = null;
    /**
     * Prefix for the v1 database tables.
     * @var string
     */
    private string $dbPrefix = '';

    public function __construct(private ManagerRegistry $doctrine, private EntityManagerInterface $entityManager, private ValidatorInterface $validator)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->setDescription('Import expenses from a Kimai v1 installation')
            ->setHelp('This command allows you to import expenses from a Kimi v1 installation')
            ->addArgument(
                'connection',
                InputArgument::REQUIRED,
                'The database connection as URL, e.g.: mysql://user:password@127.0.0.1:3306/kimai?charset=utf8'
            )
            ->addArgument('prefix', InputArgument::REQUIRED, 'The database prefix for the old Kimai v1 tables')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        // do not convert the times, Kimai 1 stored them already in UTC
        Type::overrideType(Types::DATETIME_MUTABLE, DateTimeType::class);

        // don't calculate rates ... this was done in Kimai 1
        $this->deactivateLifecycleCallbacks();

        $io = new SymfonyStyle($input, $output);

        $config = new Configuration();
        $connectionParams = ['url' => $input->getArgument('connection')];
        $this->connection = DriverManager::getConnection($connectionParams, $config);

        $prefix = $input->getArgument('prefix');
        if (!\is_string($prefix)) {
            $io->error('Database prefix must be a string');

            return Command::FAILURE;
        }
        $this->dbPrefix = $prefix;

        if (!$this->checkDatabaseVersion($io, self::MIN_VERSION, self::MIN_REVISION)) {
            return Command::FAILURE;
        }

        $bytesStart = memory_get_usage(true);

        // pre-load all data to make sure we can fully import everything
        try {
            $expenses = $this->fetchAllFromImport('expenses');
        } catch (\Exception $ex) {
            $io->error('Failed to load expenses: ' . $ex->getMessage());

            return Command::FAILURE;
        }

        try {
            $usersV1 = $this->fetchAllFromImport('users');
            $usersV2 = $this->getDoctrine()->getRepository(User::class)->findAll();
        } catch (\Exception $ex) {
            $io->error('Failed to load users: ' . $ex->getMessage());

            return Command::FAILURE;
        }

        try {
            /** @var Project[] $projects */
            $projects = $this->getDoctrine()->getRepository(Project::class)->findAll();
        } catch (\Exception $ex) {
            $io->error('Failed to load projects: ' . $ex->getMessage());

            return Command::FAILURE;
        }

        /** @var array<int, User> $userMapping */
        $userMapping = [];
        foreach ($usersV1 as $userv1) {
            foreach ($usersV2 as $userv2) {
                if ($userv1['mail'] === $userv2->getEmail()) {
                    $userMapping[$userv1['userID']] = $userv2;
                }
            }
        }

        /** @var array<int, Project> $projectMapping */
        $projectMapping = [];
        foreach ($projects as $project) {
            if (null !== $meta = $project->getMetaField('_imported_id')) {
                $projectMapping[$meta->getValue()] = $project;
            }
        }

        $bytesCached = memory_get_usage(true);

        $io->success('Fetched data, validating now ...');

        $errors = 0;

        foreach ($expenses as $expense) {
            if (!\array_key_exists($expense['userID'], $userMapping)) {
                $io->error(\sprintf('Cannot import expense %s, missing user with ID: %s', $expense['expenseID'], $expense['userID']));
                $errors++;
            }
            if (!\array_key_exists($expense['projectID'], $projectMapping)) {
                $io->error(\sprintf('Cannot import expense %s, missing project with ID: %s', $expense['expenseID'], $expense['projectID']));
                $errors++;
            }
        }

        if ($errors > 0) {
            $io->caution('Aborting due to previous errors');

            return Command::FAILURE;
        }

        $io->success('Validated data, importing now ...');

        $allImports = 0;

        try {
            $counter = $this->importExpenses($io, $expenses, $projectMapping, $userMapping);
            $allImports += $counter;
            $io->success('Imported expense records: ' . $counter);
        } catch (\Exception $ex) {
            $io->error('Failed to import expenses: ' . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString());

            return Command::FAILURE;
        }

        $bytesImported = memory_get_usage(true);

        $io->success(
            'Memory usage: ' . PHP_EOL .
            'Start: ' . $this->bytesHumanReadable($bytesStart) . PHP_EOL .
            'After caching: ' . $this->bytesHumanReadable($bytesCached) . PHP_EOL .
            'After import: ' . $this->bytesHumanReadable($bytesImported) . PHP_EOL .
            'Total consumption for importing ' . $allImports . ' new database entries: ' .
            $this->bytesHumanReadable($bytesImported - $bytesStart)
        );

        return Command::SUCCESS;
    }

    private function checkDatabaseVersion(SymfonyStyle $io, string $requiredVersion, string $requiredRevision): bool
    {
        try {
            $optionColumn = $this->connection->quoteIdentifier('option');
            $qb = $this->connection->createQueryBuilder();

            $result = $this->connection->createQueryBuilder()
                ->select('value')
                ->from($this->connection->quoteIdentifier($this->dbPrefix . 'configuration'))
                ->where($qb->expr()->eq($optionColumn, ':option'))
                ->setParameter('option', 'version')
                ->executeQuery();

            $version = $result->fetchOne();

            $result = $this->connection->createQueryBuilder()
                ->select('value')
                ->from($this->connection->quoteIdentifier($this->dbPrefix . 'configuration'))
                ->where($qb->expr()->eq($optionColumn, ':option'))
                ->setParameter('option', 'revision')
                ->executeQuery();

            $revision = $result->fetchOne();

            if (1 == version_compare($requiredVersion, $version)) {
                $io->error(
                    'Import can only performed from an up-to-date Kimai version:' . PHP_EOL .
                    'Needs at least ' . $requiredVersion . ' but found ' . $version
                );

                return false;
            }

            if (1 == version_compare($requiredRevision, $revision)) {
                $io->error(
                    'Import can only performed from an up-to-date Kimai version:' . PHP_EOL .
                    'Database revision needs to be ' . $requiredRevision . ' but found ' . $revision
                );

                return false;
            }

            return true;
        } catch (\Exception $exception) {
            $io->error('Failed to determine database version: ' . $exception->getMessage());
        }

        return false;
    }

    /**
     * Remove the timesheet lifecycle events subscriber, which would overwrite values for imported timesheet records.
     */
    private function deactivateLifecycleCallbacks(): void
    {
        $evm = $this->entityManager->getEventManager();

        /** @var object[][] $allListener */
        $allListener = $evm->getAllListeners();
        foreach ($allListener as $event => $listeners) {
            foreach ($listeners as $hash => $object) {
                if ($object instanceof DataSubscriberInterface) {
                    $evm->removeEventListener([$event], $object);
                }
            }
        }
    }

    /**
     * Thanks to "xelozz -at- gmail.com", see http://php.net/manual/en/function.memory-get-usage.php#96280
     * @param float|int $size
     * @return string
     */
    private function bytesHumanReadable(float|int $size): string
    {
        $unit = ['b', 'kB', 'MB', 'GB'];
        $i = floor(log($size, 1024));
        $a = (int) $i;

        return @round($size / pow(1024, $i), 2) . ' ' . $unit[$a];
    }

    /**
     * @param string $table
     * @param array<string> $where
     * @return array<int, array<string, mixed>>
     */
    private function fetchAllFromImport(string $table, array $where = []): array
    {
        $query = $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->connection->quoteIdentifier($this->dbPrefix . $table));

        foreach ($where as $column => $value) {
            $query->andWhere($query->expr()->eq($column, $value));
        }

        $result = $query->executeQuery();

        return $result->fetchAllAssociative();
    }

    private function getDoctrine(): ManagerRegistry
    {
        return $this->doctrine;
    }

    /**
     * @param SymfonyStyle $io
     * @param object $object
     * @return bool
     */
    private function validateImport(SymfonyStyle $io, $object): bool
    {
        $errors = $this->validator->validate($object);

        // these errors are allowed to happen during import
        $allowedError = [ExpenseConstraint::DISABLED_ACTIVITY_ERROR, ExpenseConstraint::DISABLED_PROJECT_ERROR, ExpenseConstraint::DISABLED_CUSTOMER_ERROR];

        if ($errors->count() > 0) {
            $loggedError = false;
            /** @var \Symfony\Component\Validator\ConstraintViolation $error */
            foreach ($errors as $error) {
                if (\in_array($error->getCode(), $allowedError)) {
                    continue;
                }
                $io->error(
                    (string) $error
                );
                $loggedError = true;
            }

            if ($loggedError) {
                return false;
            }
        }

        return true;
    }

    /**
     * -- are currently unsupported fields that can't be mapped
     *
     * -- ["expenseID"]=> string(1) "1"
     * ["timestamp"]=> string(10) "1306747800"
     * ["userID"]=> string(9) "228899434"
     * ["projectID"]=> string(1) "1"
     * ["designation"]=> NULL
     * ["comment"]=> string(36) "a work description"
     * -- ["commentType"]=> string(1) "0"
     * ["refundable"]=> int(1) "0"
     * ["cleared"]=> int(1) "1"
     * ["multiplier"]=> float(11) "1.5"
     * ["value"]=> float(11) "255.13"
     *
     * @param SymfonyStyle $io
     * @param array<int, array<string, mixed>> $records
     * @param array<int, Project> $projectMapping
     * @param array<int, User> $userMapping
     * @return int
     * @throws \Exception
     */
    private function importExpenses(SymfonyStyle $io, array $records, array $projectMapping, array $userMapping): int
    {
        $counter = 0;
        $failed = 0;
        $entityManager = $this->getDoctrine()->getManager();
        $total = \count($records);

        $io->writeln(\sprintf('Importing %s expenses, please wait', $total));

        $category = new ExpenseCategory('Imported expenses ' . time());
        $category->setVisible(true);

        try {
            $entityManager->persist($category);
            $entityManager->flush();
        } catch (\Exception $ex) {
            $io->error('Failed to create importer expense category: ' . $ex->getMessage());
            throw $ex;
        }

        foreach ($records as $oldRecord) {
            if (!isset($projectMapping[$oldRecord['projectID']])) {
                $io->error('Could not create expense record, missing project with ID: ' . $oldRecord['projectID']);
                $failed++;
                continue;
            }

            if (!isset($userMapping[$oldRecord['userID']])) {
                $io->error('Could not create expense record, missing user with ID: ' . $oldRecord['userID']);
                $failed++;
                continue;
            }

            $project = $projectMapping[$oldRecord['projectID']];
            $user = $userMapping[$oldRecord['userID']];

            $expense = new Expense();
            $timezone = new \DateTimeZone($user->getTimezone());
            $dateTimezone = new \DateTimeZone('UTC');

            $begin = new \DateTimeImmutable('@' . $oldRecord['timestamp'], $dateTimezone);
            $begin = $begin->setTimezone($timezone);

            $expense
                ->setDescription($oldRecord['designation'] ?? ($oldRecord['comment'] ?? null))
                ->setUser($user)
                ->setBegin($begin)
                ->setProject($project)
                ->setExported((bool) $oldRecord['cleared'])
                ->setMultiplier((float) $oldRecord['multiplier'])
                ->setCost((float) $oldRecord['value'])
                ->setRefundable((bool) $oldRecord['refundable'])
                ->setExpenseCategory($category)
            ;

            if (!$this->validateImport($io, $expense)) {
                $io->caution('Failed to validate expense record: ' . $oldRecord['expenseID'] . ' - skipping!');
                $failed++;
                continue;
            }

            try {
                $entityManager->persist($expense);
                ++$counter;
            } catch (\Exception $ex) {
                $io->error('Failed to create expense record: ' . $ex->getMessage());
                $failed++;
            }

            $io->write('.');
            if (0 == $counter % 80) {
                $entityManager->flush();
                $io->writeln(' (' . $counter . '/' . $total . ')');
            }
        }

        $entityManager->flush();

        for ($i = 0; $i < 80 - ($counter % 80); $i++) {
            $io->write(' ');
        }
        $io->writeln(' (' . $counter . '/' . $total . ')');

        if ($failed > 0) {
            $io->error(\sprintf('Failed importing %s expense records', $failed));
        }

        return $counter;
    }
}
