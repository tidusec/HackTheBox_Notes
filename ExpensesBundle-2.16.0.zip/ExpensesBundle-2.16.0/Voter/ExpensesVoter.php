<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Voter;

use App\Entity\User;
use App\Security\RolePermissionManager;
use KimaiPlugin\ExpensesBundle\Entity\Expense;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\Voter;

/**
 * @extends Voter<'view_expense'|'edit_expense'|'delete_expense', Expense>
 */
final class ExpensesVoter extends Voter
{
    /**
     * @var string[]
     */
    private static array $ALLOWED = [
        'view_expense',
        'edit_expense',
        'delete_expense',
    ];

    public function __construct(private readonly RolePermissionManager $permissionManager)
    {
    }

    public function supportsAttribute(string $attribute): bool
    {
        return \in_array($attribute, ExpensesVoter::$ALLOWED, true);
    }

    public function supportsType(string $subjectType): bool
    {
        return str_contains($subjectType, Expense::class);
    }

    protected function supports(string $attribute, mixed $subject): bool
    {
        if ($subject instanceof Expense && \in_array($attribute, ExpensesVoter::$ALLOWED, true)) {
            return true;
        }

        return false;
    }

    protected function voteOnAttribute(string $attribute, mixed $subject, TokenInterface $token): bool
    {
        $user = $token->getUser();

        if (!$user instanceof User) {
            return false;
        }

        if ($subject->getUser()->getId() !== $user->getId()) {
            if (!$this->permissionManager->hasRolePermission($user, 'view_other_timesheet')) {
                return false;
            }
        }

        switch ($attribute) {
            case 'edit_expense':
            case 'delete_expense':
                if ($subject->isExported() && !$this->permissionManager->hasRolePermission($user, 'edit_exported_expense')) {
                    return false;
                }
                break;
        }

        return $this->permissionManager->hasRolePermission($user, $attribute);
    }
}
