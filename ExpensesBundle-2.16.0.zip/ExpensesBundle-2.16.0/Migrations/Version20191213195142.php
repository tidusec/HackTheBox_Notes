<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * @version 1.6
 */
final class Version20191213195142 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Make activity optional';
    }

    public function up(Schema $schema): void
    {
        $expenses = $schema->getTable('kimai2_expense');
        $expenses->getColumn('activity_id')->setOptions(['notnull' => false]);
    }

    public function down(Schema $schema): void
    {
    }
}
