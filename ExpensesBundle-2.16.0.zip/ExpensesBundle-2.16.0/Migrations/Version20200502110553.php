<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * @version 1.12
 */
final class Version20200502110553 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds the meta field table';
    }

    public function up(Schema $schema): void
    {
        if ($schema->hasTable('kimai2_expense_meta')) {
            return;
        }
        $expenseMeta = $schema->createTable('kimai2_expense_meta');
        $expenseMeta->addColumn('id', 'integer', ['autoincrement' => true, 'notnull' => true]);
        $expenseMeta->addColumn('expense_id', 'integer', ['notnull' => true]);
        $expenseMeta->addColumn('name', 'string', ['notnull' => true, 'length' => 50]);
        $expenseMeta->addColumn('value', 'string', ['notnull' => false, 'length' => 255]);
        $expenseMeta->addColumn('visible', 'boolean', ['notnull' => true, 'default' => false]);
        $expenseMeta->setPrimaryKey(['id']);
        $expenseMeta->addIndex(['expense_id'], 'IDX_BA475C21F395DB7B');
        $expenseMeta->addUniqueIndex(['expense_id', 'name'], 'UNIQ_BA475C21F395DB7B5E237E06');
        $expenseMeta->addForeignKeyConstraint('kimai2_expense', ['expense_id'], ['id'], ['onDelete' => 'CASCADE'], 'FK_BA475C21F395DB7B');
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('kimai2_expense_meta');
    }
}
