<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

final class Version20191128104412 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Remove old permission from permission table';
    }

    public function up(Schema $schema): void
    {
        $this->addSql("DELETE FROM kimai2_roles_permissions WHERE permission = 'view_expense_other'");
    }

    public function down(Schema $schema): void
    {
    }
}
