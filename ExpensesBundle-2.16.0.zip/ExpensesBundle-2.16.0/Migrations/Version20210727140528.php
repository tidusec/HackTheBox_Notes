<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Type;
use Doctrine\DBAL\Types\Types;

/**
 * @version 1.15
 */
final class Version20210727140528 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Allows arbitrary length of meta columns';
    }

    public function up(Schema $schema): void
    {
        $expenseMeta = $schema->getTable('kimai2_expense_meta');
        $expenseMeta->getColumn('value')->setLength(65535)->setType(Type::getType(Types::TEXT));
    }

    public function down(Schema $schema): void
    {
        $expenseMeta = $schema->getTable('kimai2_expense_meta');
        $expenseMeta->getColumn('value')->setLength(255)->setType(Type::getType(Types::STRING));
    }
}
