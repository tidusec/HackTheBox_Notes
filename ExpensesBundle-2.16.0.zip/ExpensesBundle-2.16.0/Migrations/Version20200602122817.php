<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * The class name is wrong (should be Version20200206122817) but can't be changed anymore  :-(
 *
 * @version 1.8.1
 */
final class Version20200602122817 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Removes the end and duration column';
    }

    public function up(Schema $schema): void
    {
        $expenses = $schema->getTable('kimai2_expense');
        if ($expenses->hasIndex('IDX_ADFA4DF7502DF58741561401')) {
            $expenses->dropIndex('IDX_ADFA4DF7502DF58741561401');
        }
        if ($expenses->hasIndex('IDX_ADFA4DF7502DF58741561401A76ED395')) {
            $expenses->dropIndex('IDX_ADFA4DF7502DF58741561401A76ED395');
        }
        if ($expenses->hasColumn('end_time')) {
            $expenses->dropColumn('end_time');
        }
        if ($expenses->hasColumn('duration')) {
            $expenses->dropColumn('duration');
        }
    }

    public function down(Schema $schema): void
    {
        $expenses = $schema->getTable('kimai2_expense');
        $expenses->addColumn('end_time', 'datetime', ['notnull' => true, 'comment' => '(DC2Type:datetime)']);
        $expenses->addColumn('duration', 'integer', ['notnull' => true]);
        $expenses->addIndex(['start_time', 'end_time'], 'IDX_ADFA4DF7502DF58741561401');
        $expenses->addIndex(['start_time', 'end_time', 'user_id'], 'IDX_ADFA4DF7502DF58741561401A76ED395');
    }
}
