<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

final class Version20190826173413 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Creates the expenses table';
    }

    public function up(Schema $schema): void
    {
        if (!$schema->hasTable('kimai2_expense_category')) {
            $categories = $schema->createTable('kimai2_expense_category');
            $categories->addColumn('id', 'integer', ['autoincrement' => true, 'notnull' => true]);
            $categories->addColumn('name', 'string', ['notnull' => true, 'length' => 100]);
            $categories->addColumn('visible', 'boolean', ['notnull' => true, 'default' => true]);
            $categories->addUniqueIndex(['name'], 'expense_category_name');
            $categories->setPrimaryKey(['id']);
            $categories->addIndex(['name']);
        }

        if (!$schema->hasTable('kimai2_expense')) {
            $expenses = $schema->createTable('kimai2_expense');
            $expenses->addColumn('id', 'integer', ['autoincrement' => true, 'notnull' => true]);
            $expenses->addColumn('activity_id', 'integer', ['notnull' => true]);
            $expenses->addColumn('project_id', 'integer', ['notnull' => true]);
            $expenses->addColumn('category_id', 'integer', ['notnull' => true]);
            $expenses->addColumn('start_time', 'datetime', ['notnull' => true, 'comment' => '(DC2Type:datetime)']);
            $expenses->addColumn('end_time', 'datetime', ['notnull' => true, 'comment' => '(DC2Type:datetime)']);
            $expenses->addColumn('timezone', 'string', ['notnull' => true, 'length' => 64]);
            $expenses->addColumn('duration', 'integer', ['notnull' => true]);
            $expenses->addColumn('description', 'text', ['notnull' => false]);
            $expenses->addColumn('cost', 'float', ['notnull' => true, 'default' => 0]);
            $expenses->addColumn('exported', 'boolean', ['notnull' => true, 'default' => false]);
            $expenses->addColumn('refundable', 'boolean', ['notnull' => true, 'default' => true]);
            $expenses->addColumn('user_id', 'integer', ['notnull' => true]);
            $expenses->addColumn('multiplier', 'float', ['notnull' => true, 'default' => 1]);

            $expenses->setPrimaryKey(['id']);

            $expenses->addIndex(['project_id']);
            $expenses->addIndex(['user_id']);
            $expenses->addIndex(['activity_id']);
            $expenses->addIndex(['user_id', 'start_time']);
            $expenses->addIndex(['start_time']);
            $expenses->addIndex(['start_time', 'end_time'], 'IDX_ADFA4DF7502DF58741561401');
            $expenses->addIndex(['start_time', 'end_time', 'user_id'], 'IDX_ADFA4DF7502DF58741561401A76ED395');

            $expenses->addForeignKeyConstraint('kimai2_users', ['user_id'], ['id'], ['onDelete' => 'CASCADE']);
            $expenses->addForeignKeyConstraint('kimai2_activities', ['activity_id'], ['id'], ['onDelete' => 'CASCADE']);
            $expenses->addForeignKeyConstraint('kimai2_projects', ['project_id'], ['id'], ['onDelete' => 'CASCADE']);
            $expenses->addForeignKeyConstraint('kimai2_expense_category', ['category_id'], ['id'], ['onDelete' => 'CASCADE']);
        }
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('kimai2_expense');
        $schema->dropTable('kimai2_expense_category');
    }
}
