<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

final class Version20190916121739 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Deletes an unnecessary index from the expense-categories table';
    }

    public function up(Schema $schema): void
    {
        $categories = $schema->getTable('kimai2_expense_category');
        if ($categories->hasIndex('IDX_D0F42695E237E06')) {
            $categories->dropIndex('IDX_D0F42695E237E06');
        }
    }

    public function down(Schema $schema): void
    {
    }
}
