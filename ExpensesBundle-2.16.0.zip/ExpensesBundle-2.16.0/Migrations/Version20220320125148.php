<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * @version 1.25
 */
final class Version20220320125148 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds description field to expense category';
    }

    public function up(Schema $schema): void
    {
        $category = $schema->getTable('kimai2_expense_category');
        $category->addColumn('description', 'text', ['notnull' => false]);
    }

    public function down(Schema $schema): void
    {
        $expenseMeta = $schema->getTable('kimai2_expense_category');
        $expenseMeta->dropColumn('description');
    }
}
