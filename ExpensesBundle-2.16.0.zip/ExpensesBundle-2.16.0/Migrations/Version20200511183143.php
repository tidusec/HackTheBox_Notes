<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * @version 1.13
 */
final class Version20200511183143 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds a default expense category';
    }

    public function up(Schema $schema): void
    {
        $qb = $this->connection->createQueryBuilder();
        $qb->from('kimai2_expense_category')->select('count(id) as count');
        $expenseCategories = (int) $qb->executeQuery()->fetchOne();

        $this->skipIf($expenseCategories > 0, 'There is already an expense category existing');

        if ($expenseCategories === 0) {
            $this->addSql("INSERT INTO kimai2_expense_category (`name`, `visible`) VALUES ('Demo', 1)");
        }
    }

    public function down(Schema $schema): void
    {
    }
}
