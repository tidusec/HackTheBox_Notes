<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

final class Version20191118174724 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds cost column to expense categories';
    }

    public function up(Schema $schema): void
    {
        $categories = $schema->getTable('kimai2_expense_category');
        if (!$categories->hasColumn('cost')) {
            $categories->addColumn('cost', 'float', ['notnull' => false]);
        }
    }

    public function down(Schema $schema): void
    {
        $categories = $schema->getTable('kimai2_expense_category');
        $categories->dropColumn('cost');
    }
}
