<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace ExpensesBundle\Migrations;

use App\Doctrine\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * @version 1.8
 */
final class Version20200130122003 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Adds help column to expense categories';
    }

    public function up(Schema $schema): void
    {
        $categories = $schema->getTable('kimai2_expense_category');
        if (!$categories->hasColumn('help')) {
            $categories->addColumn('help', 'string', ['notnull' => false, 'length' => 100]);
        }
    }

    public function down(Schema $schema): void
    {
        $categories = $schema->getTable('kimai2_expense_category');
        $categories->dropColumn('help');
    }
}
