<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Event;

use KimaiPlugin\ExpensesBundle\Entity\Expense;
use Symfony\Contracts\EventDispatcher\Event;

/**
 * This event can be used, to dynamically add meta fields
 */
final class ExpenseMetaDefinitionEvent extends Event
{
    public function __construct(private readonly Expense $entity)
    {
    }

    public function getEntity(): Expense
    {
        return $this->entity;
    }
}
