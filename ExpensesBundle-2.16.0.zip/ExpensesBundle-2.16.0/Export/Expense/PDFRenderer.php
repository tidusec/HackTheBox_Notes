<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Export\Expense;

use App\Export\Base\PDFRenderer as BasePDFRenderer;
use KimaiPlugin\ExpensesBundle\Export\ExpenseExportInterface;

final class PDFRenderer extends BasePDFRenderer implements ExpenseExportInterface
{
    protected function getTemplate(): string
    {
        return '@export/expense-bundle.pdf.twig';
    }
}
