<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Export;

use Symfony\Component\DependencyInjection\Attribute\TaggedIterator;
use Traversable;

final class ExpenseExportService
{
    /**
     * @param Traversable<ExpenseExportInterface> $exporter
     */
    public function __construct(
        #[TaggedIterator(ExpenseExportInterface::class)]
        private readonly Traversable $exporter
    )
    {
    }

    /**
     * @return Traversable<ExpenseExportInterface>
     */
    public function getExporter(): Traversable
    {
        return $this->exporter;
    }

    public function getExporterById(string $id): ?ExpenseExportInterface
    {
        foreach ($this->exporter as $exporter) {
            if ($exporter->getId() === $id) {
                return $exporter;
            }
        }

        return null;
    }
}
