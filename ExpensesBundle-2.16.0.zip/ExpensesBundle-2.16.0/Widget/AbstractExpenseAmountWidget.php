<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Widget;

use App\Widget\Type\AbstractWidgetType;
use App\Widget\WidgetException;
use KimaiPlugin\ExpensesBundle\Repository\ExpensesRepository;

abstract class AbstractExpenseAmountWidget extends AbstractWidgetType
{
    public function __construct(private ExpensesRepository $repository)
    {
    }

    public function getTitle(): string
    {
        return 'stats.' . $this->getId();
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function getOptions(array $options = []): array
    {
        return array_merge([
            'icon' => 'fas fa-receipt',
            'dataType' => 'money',
            'begin' => null,
            'end' => null,
            'user' => true,
        ], parent::getOptions($options));
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, float>
     * @throws WidgetException
     */
    public function getData(array $options = []): array
    {
        try {
            $user = $options['user'] ? $this->getUser() : null;

            $result = $this->repository->getStatistics($options['begin'], $options['end'], $user);

            $data = [];
            foreach ($result as $currency => $values) {
                $data[$currency] = $values['rate'];
            }

            return $data;
        } catch (\Exception $ex) {
            throw new WidgetException(
                'Failed loading widget data: ' . $ex->getMessage()
            );
        }
    }

    public function getTemplateName(): string
    {
        return 'widget/widget-counter-money.html.twig';
    }
}
