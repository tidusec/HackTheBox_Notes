<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Widget;

use App\Widget\WidgetInterface;

final class ExpenseAmountTotal extends AbstractExpenseAmountWidget
{
    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function getOptions(array $options = []): array
    {
        return array_merge(parent::getOptions($options), [
            'color' => WidgetInterface::COLOR_TOTAL,
        ]);
    }
}
