<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Invoice\Calculator;

use App\Entity\ExportableItem;
use App\Invoice\Calculator\AbstractMergedCalculator;
use App\Invoice\CalculatorInterface;
use App\Invoice\InvoiceItem;
use KimaiPlugin\ExpensesBundle\Entity\Expense;

class ExpenseCategoryProjectInvoiceCalculator extends AbstractMergedCalculator implements CalculatorInterface
{
    /**
     * @return InvoiceItem[]
     */
    public function getEntries(): array
    {
        $entries = $this->model->getEntries();
        if (empty($entries)) {
            return [];
        }

        /** @var InvoiceItem[] $invoiceItems */
        $invoiceItems = [];

        foreach ($entries as $entry) {
            $id = $this->calculateSumIdentifier($entry);

            if (!isset($invoiceItems[$id])) {
                $invoiceItems[$id] = new InvoiceItem();
            }
            $invoiceItem = $invoiceItems[$id];
            $this->mergeInvoiceItems($invoiceItem, $entry);
        }

        return $this->sortEntries(array_values($invoiceItems));
    }

    /**
     * calculate identifier
     *
     * @param ExportableItem $invoiceItem
     * @return string
     */
    protected function calculateSumIdentifier(ExportableItem $invoiceItem): string
    {
        if ($invoiceItem->getType() === 'expense') {
            return 'expense_' . $invoiceItem->getCategory();
        }

        $project = $invoiceItem->getProject();

        if ($project === null) {
            return '__NULL__';
        }

        return (string) $project->getId();
    }

    protected function mergeInvoiceItems(InvoiceItem $invoiceItem, ExportableItem $entry): void
    {
        if ($entry->getType() === 'expense') {
            /** @var Expense $entry */
            $total = $invoiceItem->getRate() + $entry->getRate();
            parent::mergeInvoiceItems($invoiceItem, $entry);
            $invoiceItem->setAmount(1);
            $invoiceItem->setRate($total);
            $invoiceItem->setInternalRate($total);
            $invoiceItem->setFixedRate($total);
            $invoiceItem->setDescription($entry->getCategory());

            return;
        }

        parent::mergeInvoiceItems($invoiceItem, $entry);

        if ($entry->getProject() !== null) {
            $invoiceItem->setProject($entry->getProject());
            if ($entry->getProject()->getInvoiceText() !== null) {
                $invoiceItem->setDescription($entry->getProject()->getInvoiceText());
            } else {
                $invoiceItem->setDescription($entry->getProject()->getName());
            }
        }
    }

    public function getId(): string
    {
        return 'expense-cat-pro';
    }
}
