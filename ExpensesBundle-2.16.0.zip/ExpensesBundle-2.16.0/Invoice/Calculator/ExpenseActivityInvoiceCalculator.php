<?php

/*
 * This file is part of the "ExpensesBundle" for Kimai.
 * All rights reserved by Kevin Papst (www.kevinpapst.de).
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace KimaiPlugin\ExpensesBundle\Invoice\Calculator;

use App\Entity\ExportableItem;
use App\Invoice\Calculator\AbstractSumInvoiceCalculator;
use App\Invoice\CalculatorInterface;
use App\Invoice\InvoiceItem;

class ExpenseActivityInvoiceCalculator extends AbstractSumInvoiceCalculator implements CalculatorInterface
{
    protected function calculateSumIdentifier(ExportableItem $invoiceItem): string
    {
        if (null === $invoiceItem->getActivity()) {
            return '__NULL__';
        }

        if (null === $invoiceItem->getActivity()->getId()) {
            return '__NEW__';
        }

        return (string) $invoiceItem->getActivity()->getId();
    }

    /**
     * @param InvoiceItem $invoiceItem
     * @param ExportableItem $entry
     * @return void
     */
    protected function mergeSumInvoiceItem(InvoiceItem $invoiceItem, ExportableItem $entry): void
    {
        if (null === $entry->getActivity()) {
            return;
        }

        $invoiceItem->setActivity($entry->getActivity());

        if ($entry->getType() !== 'expense') {
            if ($entry->getActivity()->getInvoiceText() !== null) {
                $invoiceItem->setDescription($entry->getActivity()->getInvoiceText());
            } else {
                $invoiceItem->setDescription($entry->getActivity()->getName());
            }
        }
    }

    /**
     * @return string
     */
    public function getId(): string
    {
        return 'expense-activity';
    }
}
